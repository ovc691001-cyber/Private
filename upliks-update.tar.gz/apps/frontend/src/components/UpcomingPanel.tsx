export function UpcomingPanel() {
  return (
    <section className="upliks-section">
      <div className="section-title-row">
        <h2>Скоро</h2>
        <span className="subtle">Откроется для активных игроков</span>
      </div>
      <div className="mode-grid">
        <article className="mode-card upliks-card locked">
          <div className="mode-icon">⚔</div>
          <strong>Дуэли</strong>
          <p>Собирай портфель и соревнуйся с другим игроком на короткой дистанции.</p>
        </article>
        <article className="mode-card upliks-card locked">
          <div className="mode-icon">🏆</div>
          <strong>Турниры</strong>
          <p>Ежедневный формат на длинной дистанции с рейтингом и итоговой таблицей.</p>
        </article>
      </div>
    </section>
  );
}
