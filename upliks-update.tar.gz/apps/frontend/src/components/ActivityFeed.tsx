import type { ActivityItem } from "@/app/page";

export function ActivityFeed({ items }: { items: ActivityItem[] }) {
  return (
    <section className="upliks-section">
      <div className="section-title-row">
        <h2>Живая активность</h2>
        <span className="subtle">Обновляется каждые несколько секунд</span>
      </div>
      <div className="stack-list">
        {items.map((item) => (
          <article key={item.id} className="activity-item-row upliks-card">
            <span className={`activity-pulse ${item.kind}`} />
            <p>{item.text}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
