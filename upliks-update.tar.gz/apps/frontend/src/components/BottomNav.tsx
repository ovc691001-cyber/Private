import type { AppTab } from "@/app/page";

const navItems: Array<{ id: AppTab; label: string; icon: string }> = [
  { id: "lobby", label: "Лобби", icon: "⌂" },
  { id: "history", label: "История", icon: "☰" },
  { id: "rating", label: "Рейтинг", icon: "★" },
  { id: "education", label: "Обучение", icon: "⌘" },
  { id: "profile", label: "Профиль", icon: "◉" }
];

export function BottomNav({ active, onChange }: { active: AppTab; onChange: (tab: AppTab) => void }) {
  return (
    <nav className="bottom-nav">
      {navItems.map((item) => (
        <button
          key={item.id}
          type="button"
          className={`nav-item ${active === item.id ? "active" : ""}`}
          onClick={() => onChange(item.id)}
        >
          <span>{item.icon}</span>
          <small>{item.label}</small>
        </button>
      ))}
    </nav>
  );
}
