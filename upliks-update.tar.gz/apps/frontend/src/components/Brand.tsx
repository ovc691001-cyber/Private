type LogoProps = {
  compact?: boolean;
};

export function UpliksLogo({ compact = false }: LogoProps) {
  return (
    <div className={`upliks-logo${compact ? " compact" : ""}`}>
      <svg viewBox="0 0 84 84" aria-hidden="true" className="upliks-mark">
        <defs>
          <linearGradient id="upliks-u" x1="0%" x2="100%" y1="100%" y2="0%">
            <stop offset="0%" stopColor="#00E5FF" />
            <stop offset="52%" stopColor="#8A4DFF" />
            <stop offset="100%" stopColor="#C6FF4D" />
          </linearGradient>
          <linearGradient id="upliks-arrow" x1="0%" x2="100%" y1="100%" y2="0%">
            <stop offset="0%" stopColor="#A7FF37" />
            <stop offset="100%" stopColor="#C6FF4D" />
          </linearGradient>
        </defs>
        <path
          d="M17 21c0-4.4 3.6-8 8-8h4c4.4 0 8 3.6 8 8v25c0 8.3 6.7 15 15 15 8.1 0 14.8-6.5 15-14.6V21c0-4.4 3.6-8 8-8h1.5c4.4 0 8 3.6 8 8v25.2C84.5 63.6 70.5 78 53 78 33.1 78 17 61.9 17 42V21z"
          fill="url(#upliks-u)"
        />
        <path
          d="M53 17l8.2 8.2-7.4 7.4-5-5v20.7h-10.6V17H53zm12.9 0H76v10.1H65.9V17z"
          fill="url(#upliks-arrow)"
        />
      </svg>
      {!compact ? <span className="upliks-wordmark">Upliks</span> : null}
    </div>
  );
}

type CurrencyProps = {
  size?: "sm" | "md" | "lg";
};

export function CurrencyGlyph({ size = "md" }: CurrencyProps) {
  return (
    <span className={`currency-glyph ${size}`} aria-hidden="true">
      <svg viewBox="0 0 24 24">
        <defs>
          <linearGradient id="upliks-coin" x1="0%" x2="100%" y1="100%" y2="0%">
            <stop offset="0%" stopColor="#00E5FF" />
            <stop offset="55%" stopColor="#8A4DFF" />
            <stop offset="100%" stopColor="#C6FF4D" />
          </linearGradient>
        </defs>
        <circle cx="12" cy="12" r="10" fill="rgba(198,255,77,0.14)" stroke="url(#upliks-coin)" strokeWidth="1.5" />
        <path
          d="M7.2 8.2v5.5c0 2.4 2 4.4 4.4 4.4 2.4 0 4.4-1.9 4.4-4.3V8.2"
          fill="none"
          stroke="url(#upliks-coin)"
          strokeLinecap="round"
          strokeWidth="2"
        />
        <path d="M11.2 7.2h5.6v5.6" fill="none" stroke="#C6FF4D" strokeLinecap="round" strokeWidth="2" />
        <path d="M10.8 13.2l6-6" fill="none" stroke="#C6FF4D" strokeLinecap="round" strokeWidth="2" />
      </svg>
    </span>
  );
}

export function InlineValue({ value, prefix }: { value: number; prefix?: string }) {
  return (
    <span className="inline-value">
      {prefix ? <span>{prefix}</span> : null}
      <strong>{value.toLocaleString("ru-RU")}</strong>
      <CurrencyGlyph size="sm" />
    </span>
  );
}
