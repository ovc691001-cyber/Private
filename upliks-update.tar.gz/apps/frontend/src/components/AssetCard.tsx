import type { RoundAsset } from "@/app/page";

type Props = {
  asset: RoundAsset;
  selected?: boolean;
  disabled?: boolean;
  onSelect?: () => void;
  emphasis?: "lime" | "purple" | "cyan";
};

export function AssetCard({ asset, selected, disabled, onSelect, emphasis = "lime" }: Props) {
  const stroke = emphasis === "purple" ? "#8A4DFF" : emphasis === "cyan" ? "#00E5FF" : "#C6FF4D";

  return (
    <button type="button" className={`asset-card upliks-card ${selected ? "selected" : ""}`} disabled={disabled} onClick={onSelect}>
      <div className="asset-card-top">
        <div className={`asset-icon ${asset.iconToken}`}>
          <span>{asset.name.slice(0, 1)}</span>
        </div>
        <div className="asset-copy">
          <strong>{asset.name}</strong>
          <span>{asset.sector}</span>
        </div>
      </div>
      <div className="asset-graph">
        <svg viewBox="0 0 120 60" preserveAspectRatio="none" aria-hidden="true">
          <path
            d={buildGraphPath(asset.chartData)}
            fill="none"
            stroke={stroke}
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="3"
          />
        </svg>
      </div>
      <div className="asset-meta">
        <span>{asset.volatilityLabel}</span>
        <div className="volatility-dots" aria-label={`Волатильность ${asset.volatilityScore} из 5`}>
          {Array.from({ length: 5 }).map((_, index) => (
            <span key={`${asset.id}-${index}`} className={index < asset.volatilityScore ? "on" : ""} style={index < asset.volatilityScore ? { background: stroke } : undefined} />
          ))}
        </div>
      </div>
      <p className="asset-description">{asset.description}</p>
      {asset.hint ? <p className="asset-hint">{asset.hint}</p> : null}
    </button>
  );
}

function buildGraphPath(points: Array<{ tick: number; value: number }>) {
  if (!points.length) return "M0 30 L120 30";
  const min = Math.min(...points.map((item) => item.value));
  const max = Math.max(...points.map((item) => item.value));
  const range = max - min || 1;
  return points
    .map((point, index) => {
      const x = (index / Math.max(1, points.length - 1)) * 120;
      const y = 52 - ((point.value - min) / range) * 40;
      return `${index === 0 ? "M" : "L"}${x.toFixed(2)} ${y.toFixed(2)}`;
    })
    .join(" ");
}
