"use client";

import { useEffect, useMemo, useState } from "react";
import { api, ApiError, clearSessionToken, saveSessionToken } from "@/lib/api";
import { getDeviceFingerprint, getTelegramInitData, setupTelegramTheme } from "@/lib/telegram";
import { ActivityFeed } from "@/components/ActivityFeed";
import { AssetCard } from "@/components/AssetCard";
import { AuditBlock } from "@/components/AuditBlock";
import { BottomNav } from "@/components/BottomNav";
import { CurrencyGlyph, InlineValue, UpliksLogo } from "@/components/Brand";
import { EducationPanel } from "@/components/EducationPanel";
import { History } from "@/components/History";
import { Leaderboard } from "@/components/Leaderboard";
import { MissionsPanel } from "@/components/MissionsPanel";
import { ProfilePanel } from "@/components/ProfilePanel";
import { UpcomingPanel } from "@/components/UpcomingPanel";

export type AppTab = "lobby" | "history" | "rating" | "education" | "profile";

export type User = {
  id: string;
  username: string | null;
  firstName: string | null;
  photoUrl: string | null;
  nickname: string | null;
  balance: number;
  rulesAcceptedAt: string | null;
  currentStreak: number;
  bestStreak: number;
};

export type RoundAsset = {
  id: string;
  name: string;
  sector: string;
  description: string;
  volatilityType: string;
  volatilityLabel: string;
  volatilityScore: number;
  iconToken: string;
  chartData: Array<{ tick: number; value: number }>;
  finalReturn: number | null;
  returnsByHorizon: { short: number; long: number } | null;
  hint?: string | null;
};

export type Round = {
  id: string;
  status: string;
  startAt: string;
  endAt: string;
  seedHash: string;
  revealedSeed: string | null;
  winningAssetId: string | null;
  winners: { short: string | null; long: string | null };
  horizons: Array<{ id: "short" | "long"; label: string; subtitle: string }>;
  boosts?: {
    chart: boolean;
    hint: boolean;
  };
  assets: RoundAsset[];
};

export type BetHistory = {
  id: string;
  roundId: string;
  assetName: string | null;
  winningAssetName: string | null;
  amount: number;
  horizon: "short" | "long";
  status: string;
  payout: number;
  placedAt: string;
  seedHash: string | null;
  revealedSeed: string | null;
  winningAssetId: string | null;
  verifyPath: string | null;
};

export type LeaderboardRow = {
  name: string;
  photoUrl: string | null;
  betsCount: number;
  winsCount: number;
  winRate: number;
  currentStreak: number;
  netProfit: number;
  score: number;
};

export type ActivityItem = {
  id: string;
  kind: "system" | "market" | "leaderboard";
  text: string;
};

export type Mission = {
  id: string;
  title: string;
  description: string;
  target: number;
  progress: number;
  reward: number;
  claimed: boolean;
  claimable: boolean;
};

export type ProfileDetails = {
  totalRounds: number;
  wins: number;
  winRate: number;
  currentStreak: number;
  bestStreak: number;
  level: number;
};

export type ReferralOverview = {
  code: string;
  link: string;
  invitedCount: number;
  rewardsEarned: number;
  items: Array<{ id: string; name: string; roundsPlayed: number; milestoneReached: boolean }>;
};

export type EducationLessonPreview = {
  id: string;
  title: string;
  summary: string;
};

export type EducationLessonFull = EducationLessonPreview & {
  body: string[];
  quiz?: { question: string; answer: string };
};

type ModeItem = {
  id: string;
  title: string;
  description: string;
  available: boolean;
  status: string;
  note?: string;
};

type Lobby = {
  user: { balance: number; nickname: string | null; firstName: string | null; photoUrl: string | null };
  profile: ProfileDetails;
  economy: {
    betAmount: number;
    totalReturn: number;
    dailyLoginBonus: number;
    rescueAmount: number;
    boostPrices: { chart: number; hint: number };
  };
  currentRound: Round;
  modes: ModeItem[];
  history: BetHistory[];
  leaderboard: LeaderboardRow[];
  activity: ActivityItem[];
  missions: Mission[];
  referral: ReferralOverview;
};

type MeResponse = {
  user: User;
  stats: ProfileDetails;
  referral: ReferralOverview;
};

type DailyLoginResponse = {
  balance: number;
  amount: number;
  claimedAt: string;
};

type RescueResponse = {
  balance: number;
  amount: number;
  nextAvailableAt: string;
};

type BoostChartResponse = {
  type: "chart";
  assets: Array<{ id: string; name: string; chartData: Array<{ tick: number; value: number }> }>;
};

type BoostHintResponse = {
  type: "hint";
  hints: Array<{ id: string; name: string; hint: string }>;
};

type EducationResponse = {
  lessons: EducationLessonPreview[];
};

type LessonResponse = {
  lesson: EducationLessonFull;
};

const howToSteps = [
  { title: "Выбери актив и горизонт", icon: "◔" },
  { title: "Спрогнозируй движение", icon: "↑" },
  { title: "Сделай ставку и дождись результата", icon: "$" },
  { title: "Выигрывай и поднимайся в рейтинге", icon: "⌂" }
];

export default function Home() {
  const [user, setUser] = useState<User | null>(null);
  const [lobby, setLobby] = useState<Lobby | null>(null);
  const [nickname, setNickname] = useState("");
  const [rulesAccepted, setRulesAccepted] = useState(false);
  const [tab, setTab] = useState<AppTab>("lobby");
  const [selectedAsset, setSelectedAsset] = useState<string | null>(null);
  const [selectedHorizon, setSelectedHorizon] = useState<"short" | "long">("short");
  const [selectedAmount, setSelectedAmount] = useState<number>(100);
  const [showComposer, setShowComposer] = useState(false);
  const [showHowTo, setShowHowTo] = useState(true);
  const [showActivitySheet, setShowActivitySheet] = useState(false);
  const [showMissionsSheet, setShowMissionsSheet] = useState(false);
  const [lockedMode, setLockedMode] = useState<ModeItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const [chartBoostData, setChartBoostData] = useState<Record<string, Array<{ tick: number; value: number }>>>({});
  const [hintBoostData, setHintBoostData] = useState<Record<string, string>>({});
  const [lessons, setLessons] = useState<EducationLessonPreview[]>([]);
  const [activeLesson, setActiveLesson] = useState<EducationLessonFull | null>(null);

  const needsSetup = user && (!user.rulesAcceptedAt || !user.nickname);
  const round = lobby?.currentRound;
  const alreadyBet = useMemo(
    () => lobby?.history.some((bet) => bet.roundId === round?.id) ?? false,
    [lobby?.history, round?.id]
  );
  const currentBet = useMemo(
    () => lobby?.history.find((bet) => bet.roundId === round?.id) ?? null,
    [lobby?.history, round?.id]
  );
  const secondsLeft = round ? Math.max(0, Math.ceil((new Date(round.endAt).getTime() - now) / 1000)) : 0;
  const visibleAssets = useMemo(
    () =>
      round?.assets.map((asset) => ({
        ...asset,
        chartData: chartBoostData[asset.id] ?? asset.chartData,
        hint: hintBoostData[asset.id] ?? null
      })) ?? [],
    [chartBoostData, hintBoostData, round?.assets]
  );
  const spotlightAsset = useMemo(
    () => visibleAssets.find((asset) => asset.id === selectedAsset) ?? visibleAssets[0] ?? null,
    [selectedAsset, visibleAssets]
  );

  useEffect(() => {
    setupTelegramTheme();
    void boot();
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!user) return;
    const handle = window.setInterval(() => {
      void refreshActivity();
    }, 4_000);
    return () => window.clearInterval(handle);
  }, [user?.id]);

  useEffect(() => {
    if (!round || round.status !== "active") return;
    const msLeft = new Date(round.endAt).getTime() - now;
    if (msLeft > 0 || loading || busy) return;
    void refreshAll();
  }, [round?.id, round?.status, round?.endAt, now, loading, busy]);

  useEffect(() => {
    setSelectedAsset(round?.assets[0]?.id ?? null);
    setSelectedAmount(lobby?.economy.betAmount ?? 100);
    setSelectedHorizon("short");
    setChartBoostData({});
    setHintBoostData({});
  }, [round?.id, lobby?.economy.betAmount]);

  async function boot() {
    setLoading(true);
    setError(null);
    try {
      const initData = getTelegramInitData();
      if (initData) {
        const auth = await api<{ user: User; sessionToken: string }>("/auth/telegram", {
          method: "POST",
          body: { initData, deviceFingerprint: getDeviceFingerprint() }
        });
        saveSessionToken(auth.sessionToken);
        setUser(auth.user);
        setNickname(auth.user.nickname ?? auth.user.username ?? auth.user.firstName ?? "");
        setRulesAccepted(Boolean(auth.user.rulesAcceptedAt));
      } else {
        try {
          const me = await api<MeResponse>("/me");
          setUser(me.user);
          setNickname(me.user.nickname ?? "");
          setRulesAccepted(Boolean(me.user.rulesAcceptedAt));
        } catch {
          if (process.env.NODE_ENV === "production") {
            throw new ApiError("Открой приложение через кнопку Play в Telegram-боте.", 401);
          }
          const demo = createDemoState();
          setUser(demo.user);
          setLobby(demo.lobby);
          setNickname(demo.user.nickname ?? "");
          setRulesAccepted(true);
          setLessons(demo.lessons);
          setNotice("Локальный предпросмотр запущен без Telegram.");
          return;
        }
      }
      await refreshAll();
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) clearSessionToken();
      setError(err instanceof ApiError ? err.message : "Не удалось войти. Попробуй открыть Mini App в Telegram.");
    } finally {
      setLoading(false);
    }
  }

  async function refreshAll() {
    const [lobbyData, meData, educationData] = await Promise.all([
      api<Lobby>("/lobby"),
      api<MeResponse>("/me"),
      api<EducationResponse>("/education/lessons")
    ]);
    setLobby(lobbyData);
    setUser(meData.user);
    setLessons(educationData.lessons);
  }

  async function refreshActivity() {
    if (!lobby) return;
    try {
      const result = await api<{ items: ActivityItem[] }>("/activity/feed");
      setLobby((current) => (current ? { ...current, activity: result.items } : current));
    } catch {
      // keep quiet during polling
    }
  }

  async function saveProfile() {
    setBusy(true);
    setError(null);
    try {
      const result = await api<{ user: User }>("/me/profile", {
        method: "PATCH",
        body: { nickname, rulesAccepted, deviceFingerprint: getDeviceFingerprint() }
      });
      setUser(result.user);
      await refreshAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не удалось сохранить профиль");
    } finally {
      setBusy(false);
    }
  }

  async function placeBet() {
    if (!round || !selectedAsset) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      if (round.id === "demo-round") {
        placeDemoBet(round, selectedAsset, selectedAmount, selectedHorizon);
        setShowComposer(false);
        return;
      }
      await api("/bets", {
        method: "POST",
        body: { roundId: round.id, assetId: selectedAsset, horizon: selectedHorizon, amount: selectedAmount }
      });
      setNotice("Выбор зафиксирован. Следим за развитием раунда.");
      await refreshAll();
      setShowComposer(false);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Ставка не прошла");
    } finally {
      setBusy(false);
    }
  }

  async function claimDailyLogin() {
    setBusy(true);
    setError(null);
    try {
      await api<DailyLoginResponse>("/me/claim-daily-login", { method: "POST" });
      setNotice("Ежедневный бонус получен.");
      await refreshAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не удалось получить бонус");
    } finally {
      setBusy(false);
    }
  }

  async function claimRescue() {
    setBusy(true);
    setError(null);
    try {
      await api<RescueResponse>("/me/claim-rescue", { method: "POST" });
      setNotice("Баланс восстановлен.");
      await refreshAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Восстановление пока недоступно");
    } finally {
      setBusy(false);
    }
  }

  async function claimMission(missionId: string) {
    setBusy(true);
    setError(null);
    try {
      await api("/me/claim-mission", { method: "POST", body: { missionId } });
      setNotice("Награда за миссию добавлена.");
      await refreshAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не удалось забрать награду");
    } finally {
      setBusy(false);
    }
  }

  async function buyBoost(type: "history" | "hint") {
    if (!round) return;
    setBusy(true);
    setError(null);
    try {
      if (type === "history") {
        const result = await api<BoostChartResponse>(`/rounds/${round.id}/boosts/history`, { method: "POST" });
        setChartBoostData(Object.fromEntries(result.assets.map((asset) => [asset.id, asset.chartData])));
        setNotice("Открыта расширенная история актива.");
      } else {
        const result = await api<BoostHintResponse>(`/rounds/${round.id}/boosts/hint`, { method: "POST" });
        setHintBoostData(Object.fromEntries(result.hints.map((item) => [item.id, item.hint])));
        setNotice("Мягкая подсказка активирована.");
      }
      await refreshAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не удалось купить буст");
    } finally {
      setBusy(false);
    }
  }

  async function openLesson(lessonId: string) {
    setBusy(true);
    try {
      const result = await api<LessonResponse>(`/education/lessons/${lessonId}`);
      setActiveLesson(result.lesson);
      setTab("education");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Урок пока недоступен");
    } finally {
      setBusy(false);
    }
  }

  async function copyReferralLink() {
    if (!lobby?.referral.link) return;
    try {
      await navigator.clipboard.writeText(lobby.referral.link);
      setNotice("Ссылка приглашения скопирована.");
    } catch {
      setError("Не удалось скопировать ссылку");
    }
  }

  function openMode(mode: ModeItem) {
    if (mode.available) {
      setShowComposer(true);
      return;
    }
    setLockedMode(mode);
  }

  function placeDemoBet(roundToBet: Round, assetId: string, amount: number, horizon: "short" | "long") {
    const selected = roundToBet.assets.find((asset) => asset.id === assetId);
    if (!selected) return;
    const winnerId = horizon === "short" ? roundToBet.winners.short : roundToBet.winners.long;
    const winner = roundToBet.assets.find((asset) => asset.id === winnerId);
    const won = winner?.id === assetId;
    const payout = won ? Math.floor(amount * 2.7) : 0;

    setLobby((current) => {
      if (!current) return current;
      return {
        ...current,
        user: {
          ...current.user,
          balance: current.user.balance - amount + payout
        },
        profile: {
          ...current.profile,
          totalRounds: current.profile.totalRounds + 1,
          wins: current.profile.wins + (won ? 1 : 0),
          winRate: Math.round(((current.profile.wins + (won ? 1 : 0)) / (current.profile.totalRounds + 1)) * 100),
          currentStreak: won ? current.profile.currentStreak + 1 : 0,
          bestStreak: won ? Math.max(current.profile.bestStreak, current.profile.currentStreak + 1) : current.profile.bestStreak,
          level: 1 + Math.floor((current.profile.totalRounds + 1) / 5)
        },
        history: [
          {
            id: `demo-bet-${Date.now()}`,
            roundId: roundToBet.id,
            assetName: selected.name,
            winningAssetName: winner?.name ?? null,
            amount,
            horizon,
            status: won ? "won" : "lost",
            payout,
            placedAt: new Date().toISOString(),
            seedHash: roundToBet.seedHash,
            revealedSeed: "demo-local-preview-seed",
            winningAssetId: winner?.id ?? null,
            verifyPath: `/rounds/${roundToBet.id}/verify`
          },
          ...current.history
        ].slice(0, 10)
      };
    });
    setNotice(won ? "Раунд сыгран удачно." : "Раунд завершен. В этот раз рынок ушел в другую сторону.");
  }

  if (loading) return <main className="upliks-loading">Загрузка Upliks...</main>;

  if (error && !user) {
    return (
      <main className="upliks-loading">
        <div className="error-card upliks-card">
          <h1>Вход не удался</h1>
          <p>{error}</p>
          <button onClick={boot}>Повторить</button>
        </div>
      </main>
    );
  }

  if (needsSetup && user) {
    return (
      <main className="upliks-loading">
        <section className="setup-card upliks-card">
          <UpliksLogo />
          <div className="profile-row">
            {user.photoUrl ? <img src={user.photoUrl} alt="" className="hero-avatar" /> : <div className="hero-avatar fallback" />}
            <div>
              <h1>Добро пожаловать</h1>
              <p>Выбери ник и подтверди правила, чтобы открыть раунды.</p>
            </div>
          </div>
          <label className="field">
            Никнейм
            <input value={nickname} onChange={(event) => setNickname(event.target.value)} placeholder="TraderX" maxLength={24} />
          </label>
          <label className="checkline">
            <input type="checkbox" checked={rulesAccepted} onChange={(event) => setRulesAccepted(event.target.checked)} />
            <span>Внутри только игровая прогрессия, короткие раунды и рейтинговая конкуренция.</span>
          </label>
          {error ? <p className="error-text">{error}</p> : null}
          <button disabled={busy || nickname.trim().length < 2 || !rulesAccepted} onClick={saveProfile}>
            Войти в игру
          </button>
        </section>
      </main>
    );
  }

  if (!user || !lobby || !round) return null;

  const heroName = user.nickname ?? user.firstName ?? user.username ?? "Игрок";
  const heroLevel = lobby.profile.level;

  return (
    <main className="upliks-app">
      <div className="phone-shell">
        <header className="app-header upliks-card">
          <div className="brand-row">
            <UpliksLogo />
            <button type="button" className="bell-button" onClick={() => setShowActivitySheet(true)}>
              ⌁
            </button>
          </div>
          <div className="profile-summary">
            <div className="profile-badge">
              {user.photoUrl ? <img src={user.photoUrl} alt="" className="hero-avatar" /> : <div className="hero-avatar fallback" />}
              <div>
                <strong>{heroName}</strong>
                <span className="level-pill">{heroLevel}</span>
              </div>
            </div>
            <div className="balance-summary">
              <span>Баланс</span>
              <div className="balance-value">
                <strong>{lobby.user.balance.toLocaleString("ru-RU")}</strong>
                <CurrencyGlyph />
              </div>
            </div>
          </div>
        </header>

        {error ? <p className="error-text">{error}</p> : null}
        {notice ? <p className="notice-text">{notice}</p> : null}

        <section className="content-stack">
          {tab === "lobby" ? (
            <>
              <section className="round-hero upliks-card">
                <div className="round-hero-top">
                  <div>
                    <span className="hero-label">Текущий раунд</span>
                    <strong className="hero-timer">{formatDuration(secondsLeft)}</strong>
                  </div>
                  <div className="stake-chip">
                    <span>Ставка</span>
                    <strong className="value-inline">
                      {selectedAmount}
                      <CurrencyGlyph size="sm" />
                    </strong>
                  </div>
                </div>
                <div className="hero-line-chart" />
                <button type="button" className="primary-cta" onClick={() => setShowComposer(true)}>
                  Играть сейчас
                </button>
                <p className="hero-caption">Выбери актив, спрогнозируй движение и получай награды.</p>
              </section>

              <section className="upliks-section">
                <div className="section-title-row">
                  <h2>Режимы игры</h2>
                  <span className="subtle">Все карточки рабочие</span>
                </div>
                <div className="mode-grid">
                  {lobby.modes.map((mode, index) => (
                    <button
                      key={mode.id}
                      type="button"
                      className={`mode-card upliks-card ${mode.available ? "active" : "locked"} tone-${index}`}
                      onClick={() => openMode(mode)}
                    >
                      <div className="mode-icon">{index === 0 ? "⌁" : index === 1 ? "⚔" : "🏆"}</div>
                      <strong>{mode.title}</strong>
                      <p>{mode.available ? mode.description : mode.note}</p>
                    </button>
                  ))}
                </div>
              </section>

              <section className="upliks-section">
                <button type="button" className="section-title-row ghost-inline" onClick={() => setShowHowTo((value) => !value)}>
                  <h2>Как играть?</h2>
                  <span className="subtle">{showHowTo ? "Скрыть" : "Показать"}</span>
                </button>
                {showHowTo ? (
                  <article className="how-to-card upliks-card">
                    {howToSteps.map((step) => (
                      <div key={step.title} className="how-to-step">
                        <div className="how-to-icon">{step.icon}</div>
                        <span>{step.title}</span>
                      </div>
                    ))}
                  </article>
                ) : null}
              </section>

              <section className="upliks-section">
                <button type="button" className="education-promo upliks-card" onClick={() => setTab("education")}>
                  <div>
                    <h2>Научись трейдингу</h2>
                    <p>Короткие уроки о бирже, рынках и трейдинге</p>
                  </div>
                  <span className="lesson-arrow">→</span>
                </button>
              </section>

              <div className="split-grid">
                <div>
                  <div className="section-title-row">
                    <h2>Живая активность</h2>
                    <button type="button" className="ghost-button small" onClick={() => setShowActivitySheet(true)}>
                      Все события
                    </button>
                  </div>
                  <ActivityFeed items={lobby.activity.slice(0, 4)} />
                </div>

                <div>
                  <div className="section-title-row">
                    <h2>Миссии дня</h2>
                    <button type="button" className="ghost-button small" onClick={() => setShowMissionsSheet(true)}>
                      Все миссии
                    </button>
                  </div>
                  <MissionsPanel missions={lobby.missions} busy={busy} onClaim={claimMission} compact />
                </div>
              </div>

              <section className="daily-actions upliks-card">
                <button type="button" className="ghost-button" disabled={busy} onClick={claimDailyLogin}>
                  Ежедневный бонус
                </button>
                <button type="button" className="ghost-button" disabled={busy || lobby.user.balance >= 200} onClick={claimRescue}>
                  Восстановить баланс
                </button>
              </section>
            </>
          ) : null}

          {tab === "history" ? <History bets={lobby.history} /> : null}
          {tab === "rating" ? <Leaderboard rows={lobby.leaderboard} /> : null}
          {tab === "education" ? (
            <EducationPanel lessons={lessons} activeLesson={activeLesson} onSelectLesson={openLesson} onBack={() => setActiveLesson(null)} />
          ) : null}
          {tab === "profile" ? (
            <div className="stack-list">
              <ProfilePanel user={user} profile={lobby.profile} referral={lobby.referral} onCopyReferral={copyReferralLink} />
              <UpcomingPanel />
              <AuditBlock round={round} />
            </div>
          ) : null}
        </section>

        <BottomNav active={tab} onChange={setTab} />
      </div>

      {showComposer && spotlightAsset ? (
        <div className="overlay">
          <section className="overlay-panel upliks-card">
            <div className="section-title-row">
              <h2>Новый раунд</h2>
              <button type="button" className="close-button" onClick={() => setShowComposer(false)}>
                ×
              </button>
            </div>

            <article className="campaign-card upliks-card">
              <div className={`campaign-visual ${spotlightAsset.iconToken}`} />
              <div className="campaign-copy">
                <span className="hero-label">О кампании</span>
                <strong>{spotlightAsset.name}</strong>
                <p>{spotlightAsset.description}</p>
                <span className="sector-tag">{spotlightAsset.sector}</span>
              </div>
            </article>

            <section className="composer-section">
              <div className="section-title-row">
                <h3>Выбери горизонт</h3>
                <span className="subtle">Оба режима рабочие</span>
              </div>
              <div className="choice-grid">
                {round.horizons.map((horizon) => (
                  <button
                    key={horizon.id}
                    type="button"
                    className={`choice-card ${selectedHorizon === horizon.id ? "selected" : ""}`}
                    onClick={() => setSelectedHorizon(horizon.id)}
                  >
                    <strong>{horizon.label}</strong>
                    <span>{horizon.subtitle}</span>
                  </button>
                ))}
              </div>
            </section>

            <section className="composer-section">
              <div className="section-title-row">
                <h3>Выбери ставку</h3>
                <span className="subtle">Списание проверяет сервер</span>
              </div>
              <div className="stake-grid">
                {[100, 250, 500, 1000].map((amount) => (
                  <button
                    key={amount}
                    type="button"
                    className={`stake-option ${selectedAmount === amount ? "selected" : ""}`}
                    onClick={() => setSelectedAmount(amount)}
                  >
                    <span>{amount}</span>
                    <CurrencyGlyph size="sm" />
                  </button>
                ))}
                <button type="button" className="stake-option" onClick={() => setNotice("Свободный ввод ставки появится в следующем обновлении.")}>
                  Другая
                </button>
              </div>
            </section>

            <div className="boost-strip">
              <button type="button" className="ghost-button" disabled={busy} onClick={() => buyBoost("history")}>
                {round.boosts?.chart ? "История открыта" : `Доп. история ${lobby.economy.boostPrices.chart}`}
              </button>
              <button type="button" className="ghost-button" disabled={busy} onClick={() => buyBoost("hint")}>
                {round.boosts?.hint ? "Подсказка активна" : `Подсказка ${lobby.economy.boostPrices.hint}`}
              </button>
            </div>

            <section className="composer-section">
              <div className="section-title-row">
                <h3>Выбери актив</h3>
                <span className="subtle">3 вымышленные кампании</span>
              </div>
              <div className="stack-list">
                {visibleAssets.map((asset, index) => (
                  <AssetCard
                    key={asset.id}
                    asset={asset}
                    selected={selectedAsset === asset.id}
                    disabled={busy}
                    onSelect={() => setSelectedAsset(asset.id)}
                    emphasis={index === 0 ? "lime" : index === 1 ? "purple" : "cyan"}
                  />
                ))}
              </div>
            </section>

            <button type="button" className="primary-cta" disabled={busy || !selectedAsset || alreadyBet} onClick={placeBet}>
              {alreadyBet ? "Выбор уже зафиксирован" : "Подтвердить выбор"}
            </button>

            {currentBet ? (
              <div className="already-picked">
                <span>Текущий выбор: {currentBet.assetName}</span>
                <span>{currentBet.horizon === "short" ? "Ближайшие тики" : "Перспектива"}</span>
              </div>
            ) : null}

            <article className="how-to-card upliks-card mini">
              {howToSteps.map((step) => (
                <div key={step.title} className="how-to-step">
                  <div className="how-to-icon">{step.icon}</div>
                  <span>{step.title}</span>
                </div>
              ))}
              <button type="button" onClick={() => setShowComposer(false)}>
                Понятно!
              </button>
            </article>
          </section>
        </div>
      ) : null}

      {lockedMode ? (
        <div className="overlay">
          <section className="sheet-panel upliks-card">
            <div className="section-title-row">
              <h2>{lockedMode.title}</h2>
              <button type="button" className="close-button" onClick={() => setLockedMode(null)}>
                ×
              </button>
            </div>
            <p>{lockedMode.description}</p>
            <div className="status-banner">Скоро • Доступ откроется активным игрокам</div>
            <button type="button" onClick={() => setLockedMode(null)}>
              Понятно
            </button>
          </section>
        </div>
      ) : null}

      {showActivitySheet ? (
        <div className="overlay">
          <section className="sheet-panel upliks-card">
            <div className="section-title-row">
              <h2>Все события</h2>
              <button type="button" className="close-button" onClick={() => setShowActivitySheet(false)}>
                ×
              </button>
            </div>
            <ActivityFeed items={lobby.activity} />
          </section>
        </div>
      ) : null}

      {showMissionsSheet ? (
        <div className="overlay">
          <section className="sheet-panel upliks-card">
            <div className="section-title-row">
              <h2>Миссии</h2>
              <button type="button" className="close-button" onClick={() => setShowMissionsSheet(false)}>
                ×
              </button>
            </div>
            <MissionsPanel missions={lobby.missions} busy={busy} onClaim={claimMission} />
          </section>
        </div>
      ) : null}
    </main>
  );
}

function formatDuration(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

function createDemoState() {
  const now = new Date();
  const demoRound: Round = {
    id: "demo-round",
    status: "active",
    startAt: now.toISOString(),
    endAt: new Date(now.getTime() + 240_000).toISOString(),
    seedHash: "d0b1ec7f3a9c5e1f4b97f2d4a1e2c9b7f4d11e5503aa77b1234567890abcdeff",
    revealedSeed: null,
    winningAssetId: null,
    winners: { short: "asset-2", long: "asset-1" },
    horizons: [
      { id: "short", label: "Ближайшие тики", subtitle: "5 минут" },
      { id: "long", label: "Перспектива", subtitle: "1 час" }
    ],
    boosts: { chart: false, hint: false },
    assets: [
      {
        id: "asset-1",
        name: "NovaGrid",
        sector: "Технологии",
        description: "NovaGrid готовит запуск новой сети доставки данных для умных городов. Аналитики ждут рост интереса после серии партнерств.",
        volatilityType: "trend-following",
        volatilityLabel: "Трендовый",
        volatilityScore: 3,
        iconToken: "tech",
        chartData: [
          { tick: 0, value: 100.1 },
          { tick: 1, value: 100.6 },
          { tick: 2, value: 101.2 },
          { tick: 3, value: 101.7 },
          { tick: 4, value: 102.1 }
        ],
        finalReturn: null,
        returnsByHorizon: null
      },
      {
        id: "asset-2",
        name: "Voltaris",
        sector: "Зеленая энергия",
        description: "Voltaris расширяет сеть модульных накопителей энергии. На коротком отрезке рынок ждет более резкую реакцию.",
        volatilityType: "late-move",
        volatilityLabel: "Поздний импульс",
        volatilityScore: 4,
        iconToken: "energy",
        chartData: [
          { tick: 0, value: 100.2 },
          { tick: 1, value: 99.7 },
          { tick: 2, value: 100.5 },
          { tick: 3, value: 101.6 },
          { tick: 4, value: 103.2 }
        ],
        finalReturn: null,
        returnsByHorizon: null
      },
      {
        id: "asset-3",
        name: "PixelForge",
        sector: "Медиа",
        description: "PixelForge анонсировала платформу генерации игровых миров. Модель ждет шумный рисунок с разворотами.",
        volatilityType: "choppy",
        volatilityLabel: "Шумный",
        volatilityScore: 5,
        iconToken: "media",
        chartData: [
          { tick: 0, value: 100.4 },
          { tick: 1, value: 100.1 },
          { tick: 2, value: 99.6 },
          { tick: 3, value: 100.5 },
          { tick: 4, value: 100.2 }
        ],
        finalReturn: null,
        returnsByHorizon: null
      }
    ]
  };

  return {
    user: {
      id: "demo-user",
      username: "local_demo",
      firstName: "Local",
      photoUrl: null,
      nickname: "TraderX",
      balance: 1250,
      rulesAcceptedAt: now.toISOString(),
      currentStreak: 2,
      bestStreak: 4
    } satisfies User,
    lobby: {
      user: { balance: 1250, nickname: "TraderX", firstName: "Local", photoUrl: null },
      profile: { totalRounds: 12, wins: 6, winRate: 50, currentStreak: 2, bestStreak: 4, level: 17 },
      economy: {
        betAmount: 100,
        totalReturn: 270,
        dailyLoginBonus: 200,
        rescueAmount: 200,
        boostPrices: { chart: 50, hint: 100 }
      },
      currentRound: demoRound,
      modes: [
        { id: "quick", title: "Быстрый раунд", description: "Выбери актив, спрогнозируй движение и забери награду.", available: true, status: "available" },
        { id: "duels", title: "Дуэли", description: "Собирай портфель и соревнуйся с другим игроком на короткой дистанции.", available: false, status: "locked", note: "Доступно самым активным игрокам" },
        { id: "daily-event", title: "Ежедневное событие", description: "Длинная дистанция с общей таблицей и серией заданий дня.", available: false, status: "locked", note: "Доступно самым активным игрокам" }
      ],
      history: [],
      leaderboard: [
        { name: "TraderX", photoUrl: null, betsCount: 7, winsCount: 4, winRate: 57, currentStreak: 3, netProfit: 280, score: 280 },
        { name: "WaveRider", photoUrl: null, betsCount: 5, winsCount: 3, winRate: 60, currentStreak: 2, netProfit: 140, score: 140 }
      ],
      activity: [
        { id: "a1", kind: "system", text: "В этом раунде сделано выборов: 21" },
        { id: "a2", kind: "market", text: "Чаще выбирают: Voltaris" },
        { id: "a3", kind: "market", text: "Последний результат раунда: +170" },
        { id: "a4", kind: "leaderboard", text: "Серия побед у лидера: 3" },
        { id: "a5", kind: "system", text: "Новый раунд стартует через 00:24" }
      ],
      missions: [
        { id: "play_five_rounds", title: "Сыграй 5 раундов", description: "Проведи пять раундов за день.", target: 5, progress: 2, reward: 100, claimed: false, claimable: false },
        { id: "use_one_boost", title: "Используй 1 инфо-буст", description: "Купи подсказку или дополнительную историю.", target: 1, progress: 0, reward: 75, claimed: false, claimable: false },
        { id: "play_long_horizon", title: "Сыграй перспективу", description: "Попробуй длинный горизонт хотя бы один раз.", target: 1, progress: 0, reward: 50, claimed: false, claimable: false }
      ],
      referral: {
        code: "ref_demo",
        link: "https://t.me/UpliksBot?start=ref_demo",
        invitedCount: 2,
        rewardsEarned: 600,
        items: [
          { id: "ref-1", name: "MoonLeaf", roundsPlayed: 4, milestoneReached: true },
          { id: "ref-2", name: "AeroMint", roundsPlayed: 1, milestoneReached: false }
        ]
      }
    } satisfies Lobby,
    lessons: [
      { id: "what-is-market", title: "Что такое биржа?", summary: "Это место, где встречаются спрос и предложение." },
      { id: "volatility", title: "Что такое волатильность?", summary: "Это сила и частота колебаний цены." },
      { id: "risk", title: "Что такое риск?", summary: "Это вероятность ошибиться плюс размер последствий." }
    ] satisfies EducationLessonPreview[]
  };
}
