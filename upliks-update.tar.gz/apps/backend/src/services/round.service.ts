import { ForecastHorizon, Prisma, PrismaClient, RoundStatus } from "@prisma/client";
import { roundConfig } from "../config.js";
import { badRequest } from "../lib/errors.js";
import { generateSeed, sha256Hex } from "../utils/crypto.js";
import { addSeconds } from "../utils/time.js";
import { applyBalanceChange } from "./economy.service.js";
import { maybeAwardReferralMilestone } from "./referral.service.js";
import { generateRoundFromSeed, returnForHorizon, verifyRound } from "./round-engine.js";

type Db = PrismaClient | Prisma.TransactionClient;

type RoundWithAssets = Awaited<ReturnType<typeof ensureCurrentRound>>;
type ChartPoint = { tick: number; value: number };

export async function ensureCurrentRound(db: Db, now = new Date()) {
  const active = await db.round.findFirst({
    where: {
      status: RoundStatus.active,
      startAt: { lte: now },
      endAt: { gt: now }
    },
    include: { assets: true },
    orderBy: { startAt: "desc" }
  });
  if (active) return active;

  const seed = generateSeed();
  const engine = generateRoundFromSeed(seed, roundConfig);
  const startAt = now;
  const endAt = addSeconds(startAt, roundConfig.durationSeconds);

  return db.round.create({
    data: {
      status: RoundStatus.active,
      startAt,
      endAt,
      seedHash: sha256Hex(seed),
      seedSecret: seed,
      configJson: roundConfig,
      revealedSeed: null,
      assets: {
        create: engine.assets.map((asset) => ({
          name: asset.name,
          metaJson: asset.meta,
          volatilityType: asset.volatilityType,
          chartDataJson: asset.chartData,
          finalReturn: asset.longReturn
        }))
      }
    },
    include: { assets: true }
  });
}

export function serializeRound(round: RoundWithAssets) {
  const revealFullResult = round.status === "finished" || Boolean(round.revealedSeed);
  const durationMs = Math.max(1, round.endAt.getTime() - round.startAt.getTime());
  const elapsedRatio = Math.min(1, Math.max(0, (Date.now() - round.startAt.getTime()) / durationMs));
  const winners = buildRoundWinners(round);

  return {
    id: round.id,
    status: round.status,
    roundType: round.roundType,
    startAt: round.startAt.toISOString(),
    endAt: round.endAt.toISOString(),
    seedHash: round.seedHash,
    revealedSeed: round.revealedSeed,
    winningAssetId: round.winningAssetId,
    config: round.configJson,
    settledAt: round.settledAt?.toISOString() ?? null,
    horizons: [
      { id: "short", label: "Ближайшие тики", subtitle: "5 минут" },
      { id: "long", label: "Перспектива", subtitle: "1 час" }
    ],
    winners,
    assets: round.assets.map((asset) => {
      const meta = assetMeta(asset.metaJson);
      const chartData = chartPoints(asset.chartDataJson);
      return {
        id: asset.id,
        name: asset.name,
        sector: meta.sector,
        iconToken: meta.iconToken,
        description: meta.description,
        volatilityType: asset.volatilityType,
        volatilityLabel: volatilityLabel(asset.volatilityType),
        volatilityScore: meta.volatilityScore,
        chartData: visibleChartData(chartData, elapsedRatio, revealFullResult),
        finalReturn: revealFullResult ? Number(asset.finalReturn) : null,
        returnsByHorizon: revealFullResult ? computeReturns(chartData) : null
      };
    })
  };
}

function buildRoundWinners(round: RoundWithAssets) {
  const seed = round.revealedSeed ?? round.seedSecret;
  const engine = verifyRound(seed, parseRoundConfig(round.configJson));
  const sortedAssets = [...round.assets].sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());

  return {
    short: sortedAssets[engine.winningEngineIdByHorizon.short]?.id ?? null,
    long: sortedAssets[engine.winningEngineIdByHorizon.long]?.id ?? null
  };
}

function visibleChartData(chartData: ChartPoint[], elapsedRatio: number, revealFullResult: boolean) {
  if (revealFullResult) return chartData;
  const visibleCount = Math.max(1, Math.min(roundConfig.publicTicks, Math.ceil(chartData.length * elapsedRatio)));
  return chartData.slice(0, visibleCount);
}

function computeReturns(chartData: ChartPoint[]) {
  const baseline = chartData[0]?.value ?? 100;
  const shortValue = chartData[Math.min(roundConfig.shortTickIndex, chartData.length - 1)]?.value ?? baseline;
  const longValue = chartData[Math.min(roundConfig.longTickIndex, chartData.length - 1)]?.value ?? baseline;
  return {
    short: round6(((shortValue - baseline) / baseline) * 100),
    long: round6(((longValue - baseline) / baseline) * 100)
  };
}

export async function settleDueRounds(db: PrismaClient, now = new Date()): Promise<number> {
  const rounds = await db.round.findMany({
    where: { status: RoundStatus.active, endAt: { lte: now } },
    include: { assets: true, bets: true }
  });

  for (const round of rounds) {
    await db.$transaction(async (tx) => {
      const locked = await tx.round.findUniqueOrThrow({
        where: { id: round.id },
        include: { assets: true, bets: true }
      });
      if (locked.status !== RoundStatus.active) return;

      const engine = verifyRound(locked.seedSecret, parseRoundConfig(locked.configJson));
      const sortedAssets = [...locked.assets].sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
      const defaultWinner = sortedAssets[engine.winningEngineIdByHorizon.long];
      if (!defaultWinner) throw badRequest("Winning asset cannot be resolved");

      for (const bet of locked.bets) {
        if (bet.status !== "pending") continue;

        const winningAsset =
          sortedAssets[
            bet.horizon === "short" ? engine.winningEngineIdByHorizon.short : engine.winningEngineIdByHorizon.long
          ];
        if (!winningAsset) throw badRequest("Winning asset cannot be resolved");

        const won = bet.assetId === winningAsset.id;
        const payout = won ? Math.floor(bet.amount * roundConfig.payoutMultiplier) : 0;
        const user = await tx.user.findUniqueOrThrow({ where: { id: bet.userId } });

        if (won) {
          await applyBalanceChange(tx, {
            userId: user.id,
            delta: payout,
            type: "bet_win",
            referenceType: "bet",
            referenceId: bet.id,
            idempotencyKey: `bet_win:${bet.id}`
          });
        }

        await tx.bet.update({
          where: { id: bet.id },
          data: { status: won ? "won" : "lost", payout, settledAt: now }
        });

        await tx.user.update({
          where: { id: user.id },
          data: won
            ? {
                currentStreak: { increment: 1 },
                bestStreak: Math.max(user.bestStreak, user.currentStreak + 1)
              }
            : { currentStreak: 0 }
        });

        const date = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
        await tx.leaderboardDaily.upsert({
          where: { userId_date: { userId: user.id, date } },
          create: {
            userId: user.id,
            date,
            betsCount: 1,
            winsCount: won ? 1 : 0,
            totalWagered: bet.amount,
            totalPayout: payout,
            netProfit: payout - bet.amount
          },
          update: {
            betsCount: { increment: 1 },
            winsCount: { increment: won ? 1 : 0 },
            totalWagered: { increment: bet.amount },
            totalPayout: { increment: payout },
            netProfit: { increment: payout - bet.amount }
          }
        });

        await maybeAwardReferralMilestone(tx, user.id);
      }

      await tx.round.update({
        where: { id: locked.id },
        data: {
          status: RoundStatus.finished,
          revealedSeed: locked.seedSecret,
          seedHash: sha256Hex(locked.seedSecret),
          winningAssetId: defaultWinner.id,
          settledAt: now
        }
      });
    });
  }

  return rounds.length;
}

export function getWinningAssetForBet(
  round: {
    revealedSeed: string | null;
    seedSecret?: string;
    configJson: Prisma.JsonValue;
    assets: Array<{
      id: string;
      name: string;
      createdAt?: Date;
      chartDataJson?: Prisma.JsonValue;
      finalReturn?: Prisma.Decimal;
    }>;
  },
  horizon: ForecastHorizon
) {
  const seed = round.revealedSeed ?? round.seedSecret;
  if (!seed) return null;
  const engine = verifyRound(seed, parseRoundConfig(round.configJson));
  const sortedAssets = [...round.assets].sort((a, b) => {
    if (!a.createdAt || !b.createdAt) return 0;
    return a.createdAt.getTime() - b.createdAt.getTime();
  });
  return sortedAssets[horizon === "short" ? engine.winningEngineIdByHorizon.short : engine.winningEngineIdByHorizon.long] ?? null;
}

function volatilityLabel(type: string) {
  switch (type) {
    case "pumpy":
      return "Импульсный";
    case "stable":
      return "Стабильный";
    case "false-breakout":
      return "Ложный пробой";
    case "late-move":
      return "Поздний импульс";
    case "choppy":
      return "Шумный";
    default:
      return "Трендовый";
  }
}

function assetMeta(value: Prisma.JsonValue) {
  const meta = (value ?? {}) as Partial<{
    sector: string;
    description: string;
    iconToken: string;
    volatilityScore: number;
    hintProfile: string;
  }>;

  return {
    sector: meta.sector ?? "Технологии",
    description: meta.description ?? "Новая вымышленная кампания с высокой чувствительностью к новостному фону.",
    iconToken: meta.iconToken ?? "tech",
    volatilityScore: meta.volatilityScore ?? 3,
    hintProfile: meta.hintProfile ?? "Первые тики не всегда показывают настоящее направление."
  };
}

function round6(value: number) {
  return Math.round(value * 1_000_000) / 1_000_000;
}

function parseRoundConfig(value: Prisma.JsonValue): typeof roundConfig {
  return value as unknown as typeof roundConfig;
}

function chartPoints(value: Prisma.JsonValue): ChartPoint[] {
  if (!Array.isArray(value)) return [];
  return value as unknown as ChartPoint[];
}
