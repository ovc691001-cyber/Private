import { ForecastHorizon } from "@prisma/client";
import { sha256Hex } from "../utils/crypto.js";

export type RoundEngineConfig = {
  assetCount: number;
  ticks: number;
  publicTicks: number;
  shortTickIndex: number;
  longTickIndex: number;
  durationSeconds: number;
  betAmount: number;
  payoutMultiplier: number;
  betOptions: readonly number[];
};

export type EngineAssetMeta = {
  sector: string;
  description: string;
  iconToken: string;
  volatilityScore: number;
  hintProfile: string;
};

export type EngineAsset = {
  engineId: number;
  name: string;
  volatilityType: string;
  chartData: { tick: number; value: number }[];
  shortReturn: number;
  longReturn: number;
  meta: EngineAssetMeta;
};

export type EngineRoundResult = {
  seedHash: string;
  assets: EngineAsset[];
  winningEngineIdByHorizon: Record<ForecastHorizon, number>;
};

type Archetype = {
  key: string;
  drift: number;
  amplitude: number;
  lateMove: number;
  meanRevert: number;
  score: number;
  hints: string[];
};

const nameLeft = ["Nova", "Pixel", "Sun", "Cry", "Volt", "Neuron", "Aero", "Quant", "Sky", "Pulse", "Luma", "Echo"];
const nameRight = ["Grid", "Forge", "Loom", "Texa", "Aris", "Nest", "Mint", "Leaf", "Wave", "Circuit", "Dock", "Rise"];

const sectors = [
  {
    name: "Технологии",
    iconToken: "tech",
    hooks: [
      "готовит запуск новой инфраструктуры для умных городов",
      "анонсировала платформу генерации игровых миров",
      "проверяет спрос после серии партнерств с индустриальными хабами"
    ],
    endings: [
      "Рынок ждет резкую реакцию на новости и заметную волатильность.",
      "Интерес подогревают разговоры о масштабировании и новых интеграциях.",
      "Ожидания высокие, но участники модели спорят о темпе роста."
    ]
  },
  {
    name: "Зеленая энергия",
    iconToken: "energy",
    hooks: [
      "расширяет сеть модульных накопителей энергии",
      "тестирует новую линию распределения зарядных решений",
      "выходит в пилот с гибкими микросетями"
    ],
    endings: [
      "Инвесторы внимательно следят, выдержит ли проект темп расширения.",
      "На горизонте возможны плавные движения с поздним импульсом.",
      "Волатильность держится выше среднего из-за спорных прогнозов."
    ]
  },
  {
    name: "Медиа",
    iconToken: "media",
    hooks: [
      "запускает интерактивную студию коротких форматов",
      "обновляет движок персонализации рекомендаций",
      "готовит масштабное партнерство с креативными платформами"
    ],
    endings: [
      "Реакция модели может резко меняться после первых отзывов.",
      "Игровой рынок любит этот сектор за неожиданные развороты.",
      "В центре внимания баланс между шумом и настоящим спросом."
    ]
  },
  {
    name: "Логистика",
    iconToken: "logistics",
    hooks: [
      "строит сеть быстрой доставки для автономных складов",
      "тестирует систему синхронизации городских маршрутов",
      "усиливает направление микрохабов последней мили"
    ],
    endings: [
      "Ожидается сдержанный старт с шансом на сильный финальный рывок.",
      "Участники модели отмечают устойчивый спрос без лишнего шума.",
      "Сектор выглядит спокойным, но на длинной дистанции скрывает ускорение."
    ]
  },
  {
    name: "Космос",
    iconToken: "space",
    hooks: [
      "проводит серию испытаний орбитальных сенсоров",
      "объявила о новой программе наблюдения за климатом",
      "готовит демонстрацию платформы спутниковой связи"
    ],
    endings: [
      "Такой сюжет часто приносит нервное, но зрелищное движение.",
      "Модель ждет широкий диапазон колебаний и поздний импульс.",
      "Спрос на идею высокий, однако рынок не любит неопределенность."
    ]
  }
];

const archetypes: Archetype[] = [
  {
    key: "pumpy",
    drift: 0.7,
    amplitude: 2.8,
    lateMove: 1.8,
    meanRevert: 0.1,
    score: 5,
    hints: ["Есть шанс позднего импульса.", "Поведение чаще ускоряется ближе к финалу."]
  },
  {
    key: "stable",
    drift: 0.25,
    amplitude: 1.2,
    lateMove: 0.4,
    meanRevert: 0.35,
    score: 2,
    hints: ["Плавное движение может оказаться сильнее короткого шума.", "Этот актив чаще стабилен, чем кажется."]
  },
  {
    key: "false-breakout",
    drift: 0.12,
    amplitude: 3.1,
    lateMove: -0.7,
    meanRevert: 0.75,
    score: 4,
    hints: ["Резкие всплески здесь не всегда держатся долго.", "Шум может маскировать возврат к среднему."]
  },
  {
    key: "late-move",
    drift: 0.15,
    amplitude: 1.9,
    lateMove: 1.35,
    meanRevert: 0.2,
    score: 3,
    hints: ["Основное движение часто раскрывается ближе к концу.", "Первые тики не всегда показывают настоящий темп."]
  },
  {
    key: "choppy",
    drift: 0.08,
    amplitude: 3.6,
    lateMove: 0.15,
    meanRevert: 0.5,
    score: 5,
    hints: ["Небольшой шум может скрывать основное направление.", "Здесь особенно важно не переоценивать ранний всплеск."]
  },
  {
    key: "trend-following",
    drift: 0.45,
    amplitude: 1.7,
    lateMove: 0.8,
    meanRevert: 0.12,
    score: 3,
    hints: ["Если направление поймано рано, оно часто держится дольше ожиданий.", "Поведение похоже на устойчивый рост, но без резких всплесков."]
  }
];

function xmur3(str: string): () => number {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i += 1) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return () => {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    return (h ^= h >>> 16) >>> 0;
  };
}

function mulberry32(seed: number): () => number {
  return () => {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function deterministicRandom(seed: string): () => number {
  return mulberry32(xmur3(seed)());
}

function round6(value: number): number {
  return Math.round(value * 1_000_000) / 1_000_000;
}

export function generateRoundFromSeed(seed: string, config: RoundEngineConfig): EngineRoundResult {
  const random = deterministicRandom(seed);
  const usedNames = new Set<string>();
  const assets: EngineAsset[] = [];

  for (let index = 0; index < config.assetCount; index += 1) {
    const archetype = archetypes[Math.floor(random() * archetypes.length)] ?? archetypes[0]!;
    const sector = sectors[Math.floor(random() * sectors.length)] ?? sectors[0]!;
    const name = uniqueCampaignName(random, usedNames);
    const meta = buildCampaignMeta(random, sector, archetype);
    let value = 100 + (random() - 0.5) * 3;
    const baseline = value;
    const chartData: { tick: number; value: number }[] = [];

    for (let tick = 0; tick < config.ticks; tick += 1) {
      const phase = tick / Math.max(1, config.ticks - 1);
      const directionalPush = archetype.drift + phase * archetype.lateMove;
      const noise = (random() - 0.5) * archetype.amplitude;
      const wobble = Math.sin((tick + 1) * (index + 1) * 0.9) * 0.8;
      const pullback = (baseline - value) * archetype.meanRevert * 0.08;
      value = Math.max(1, value + directionalPush + noise + wobble + pullback);
      chartData.push({ tick, value: round6(value) });
    }

    const shortValue = chartData[Math.min(config.shortTickIndex, chartData.length - 1)]?.value ?? value;
    const longValue = chartData[Math.min(config.longTickIndex, chartData.length - 1)]?.value ?? value;

    assets.push({
      engineId: index,
      name,
      volatilityType: archetype.key,
      chartData,
      shortReturn: round6(((shortValue - baseline) / baseline) * 100),
      longReturn: round6(((longValue - baseline) / baseline) * 100),
      meta
    });
  }

  const winningEngineIdByHorizon = {
    short: pickWinner(assets, "shortReturn"),
    long: pickWinner(assets, "longReturn")
  };

  return {
    seedHash: sha256Hex(seed),
    assets,
    winningEngineIdByHorizon
  };
}

export function verifyRound(seed: string, config: RoundEngineConfig): EngineRoundResult {
  return generateRoundFromSeed(seed, config);
}

export function returnForHorizon(asset: Pick<EngineAsset, "shortReturn" | "longReturn">, horizon: ForecastHorizon) {
  return horizon === "short" ? asset.shortReturn : asset.longReturn;
}

function pickWinner(assets: EngineAsset[], key: "shortReturn" | "longReturn") {
  return [...assets].sort((a, b) => b[key] - a[key] || a.engineId - b.engineId)[0]!.engineId;
}

function uniqueCampaignName(random: () => number, used: Set<string>) {
  for (let attempt = 0; attempt < 20; attempt += 1) {
    const candidate = `${nameLeft[Math.floor(random() * nameLeft.length)]}${nameRight[Math.floor(random() * nameRight.length)]}`;
    if (!used.has(candidate)) {
      used.add(candidate);
      return candidate;
    }
  }
  const fallback = `Vector${used.size + 1}`;
  used.add(fallback);
  return fallback;
}

function buildCampaignMeta(random: () => number, sector: (typeof sectors)[number], archetype: Archetype): EngineAssetMeta {
  const hook = sector.hooks[Math.floor(random() * sector.hooks.length)] ?? sector.hooks[0]!;
  const ending = sector.endings[Math.floor(random() * sector.endings.length)] ?? sector.endings[0]!;
  const hint = archetype.hints[Math.floor(random() * archetype.hints.length)] ?? archetype.hints[0]!;

  return {
    sector: sector.name,
    iconToken: sector.iconToken,
    volatilityScore: archetype.score,
    description: `${capitalize(hook)}. ${ending}`,
    hintProfile: hint
  };
}

function capitalize(value: string) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}
