import { describe, expect, it } from "vitest";
import { placeBetSchema } from "@volatility/shared";
import { roundConfig } from "../src/config.js";
import { generateRoundFromSeed, verifyRound } from "../src/services/round-engine.js";

describe("round engine", () => {
  it("is deterministic", () => {
    const a = generateRoundFromSeed("seed-a", roundConfig);
    const b = generateRoundFromSeed("seed-a", roundConfig);
    expect(a).toEqual(b);
  });

  it("produces fictional campaigns with valid structure", () => {
    const result = generateRoundFromSeed("seed-fictional", roundConfig);
    expect(result.assets).toHaveLength(3);
    for (const asset of result.assets) {
      expect(asset.name).toMatch(/^[A-Z][a-zA-Z]+$/);
      expect(asset.meta.description.toLowerCase()).not.toContain("apple");
      expect(asset.meta.sector.length).toBeGreaterThan(2);
      expect(asset.chartData.length).toBe(roundConfig.ticks);
    }
  });

  it("verifyRound reproduces result", () => {
    expect(verifyRound("seed-b", roundConfig)).toEqual(generateRoundFromSeed("seed-b", roundConfig));
  });

  it("validates horizon and stake choices through schema", () => {
    expect(() =>
      placeBetSchema.parse({ roundId: "550e8400-e29b-41d4-a716-446655440000", assetId: "550e8400-e29b-41d4-a716-446655440001", horizon: "short", amount: 500 })
    ).not.toThrow();
    expect(() =>
      placeBetSchema.parse({ roundId: "550e8400-e29b-41d4-a716-446655440000", assetId: "550e8400-e29b-41d4-a716-446655440001", horizon: "week", amount: 500 })
    ).toThrow();
  });
});
