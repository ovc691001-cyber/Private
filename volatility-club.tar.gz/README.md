# Volatility Club MVP

Volatility Club is a Telegram Mini App game about forecasting which fictional asset will finish a short round with the best growth. The current product is a clean early-stage virtual economy experience built around one in-game currency: `бурмалда`.

## Product Snapshot

- One active round at a time with 3 fictional assets.
- Fixed entry cost: `100` бурмалды.
- Exact pick pays `270` total return, so the player nets `+170`.
- Daily loop:
  - `+200` daily login bonus;
  - three daily missions, `+100` each;
  - rescue refill `+200` when balance is under `200`, no more than once per 3 hours.
- Info boosts for бурмалда only:
  - expanded chart for the round;
  - pattern hint for the round.
- Daily leaderboard, referral rewards, compact fairness block, and live activity feed.
- Upcoming mode cards for Duels and Tournaments, but no unfinished gameplay exposed as playable.

## Architecture

- `apps/frontend` - Next.js Telegram Mini App UI
- `apps/backend` - Express API + Prisma
- `packages/shared` - shared schemas and DTO contracts
- `infra` - production Docker/Caddy files
- `docs` - HTTP examples and deployment notes

The project stays intentionally compact: one backend, one frontend, PostgreSQL, Redis, Docker, and a small set of services. Telegram auth and round fairness remain server-authoritative.

## Core Gameplay

1. The player opens the Mini App through Telegram.
2. The backend validates `Telegram.WebApp.initData`.
3. The player receives a starting balance of `1000` бурмалды.
4. In each round the player chooses one of 3 assets.
5. The server settles the round from a deterministic seed.
6. Before settlement the app shows `seedHash`; after settlement it reveals the seed and exposes a verify endpoint.

## Economy

### Currency

- Only one currency exists: `бурмалда`

### Round Math

- Start balance: `1000`
- Main round cost: `100`
- Winning total return: `270`
- Net gain on win: `+170`
- Loss on miss: `-100`

### Daily Bonuses

- Daily login: `+200` once per UTC day
- Mission `Сыграй 5 раундов`: `+100`
- Mission `Выиграй 2 раунда`: `+100`
- Mission `Собери серию из 2 побед`: `+100`

Maximum mission + login income per day is `500` бурмалды.

### Rescue

If the player's balance drops below `200`, they can claim a `+200` rescue refill. Cooldown: once every 3 hours.

### Referrals

- Friend joined with your code: `+300`
- The same friend completes 3 settled rounds: another `+300`

Referral rewards are server-side and idempotent.

## Info Boosts

All boosts are purchased only with бурмалда.

- Expanded chart: `50`
  - unlocks the full round chart instead of the short preview
- Pattern hint: `100`
  - returns a textual pattern clue derived from the asset archetype

Boosts never change the seed, winner, or settlement logic.

## Fairness

- Each round is created from a server-generated seed.
- The app shows `seedHash` before settlement.
- After settlement the seed is revealed.
- `GET /rounds/:id/verify` recomputes the round from the revealed seed and config.

## Local Setup

### Requirements

- Node.js 22+
- pnpm 9+
- Docker Desktop

### 1. Create env

```bash
cp .env.example .env
```

Fill in:

```env
TELEGRAM_BOT_TOKEN=your_bot_token
SESSION_SECRET=long_random_secret
INTERNAL_SECRET=long_internal_secret
```

### 2. Start PostgreSQL and Redis

```bash
docker compose up -d
```

### 3. Install dependencies

```bash
pnpm install
```

### 4. Generate Prisma client and apply migrations

```bash
pnpm db:generate
pnpm db:migrate
```

### 5. Seed a local round

```bash
pnpm db:seed
```

### 6. Run the app

```bash
pnpm dev
```

Open:

- Frontend: `http://localhost:3000`
- Backend health: `http://localhost:4000/health`

## Local Preview Without Telegram

For browser-only preview keep this in `.env`:

```env
ENABLE_DEV_AUTH=true
```

Then `POST /auth/dev` is available only in local development and lets the frontend open without Telegram.

## Telegram Setup

1. Create a bot in BotFather.
2. Put the bot token into `.env`.
3. Expose the frontend and backend via HTTPS or deploy to VPS.
4. In BotFather set the Mini App / menu button URL to:

```text
https://app.your-domain.tld
```

5. Open the bot and press `Play`.

## Main API

- `POST /auth/telegram`
- `GET /me`
- `PATCH /me/profile`
- `GET /me/missions`
- `POST /me/claim-daily-login`
- `POST /me/claim-mission`
- `POST /me/claim-rescue`
- `GET /lobby`
- `GET /activity/feed`
- `GET /rounds/current`
- `GET /rounds/:id`
- `GET /rounds/:id/verify`
- `POST /rounds/:id/boosts/chart`
- `POST /rounds/:id/boosts/hint`
- `POST /bets`
- `GET /bets/history`
- `GET /leaderboard/daily`
- `GET /referral`
- `POST /internal/rounds/tick`

Examples live in [docs/http-examples.http](docs/http-examples.http).

## Tests

The test suite covers:

- Telegram initData validation
- round determinism
- one-bet-per-round guard model
- 270 payout calculation
- rescue cooldown logic
- boost affordability logic
- referral key/idempotency helpers
- activity item shape
- UI copy staying virtual-only

Note: on this Windows environment, Vitest currently hits a local `spawn EPERM` issue under the Cyrillic home path, so the files are updated but the runner may still fail before executing them.

## Production Deployment

Use:

- `.env.production.example`
- `infra/docker-compose.prod.yml`
- `infra/Caddyfile`
- `docs/vps-deployment.md`

For a deployed VPS flow:

```bash
docker compose --env-file .env.production -f infra/docker-compose.prod.yml up -d --build
```

## Current Product Positioning

Volatility Club is now a virtual-currency Telegram game focused on:

- short predictive rounds
- healthy repeatable sessions
- referrals
- missions
- leaderboard competition
- compact trust/fairness

Duels and Tournaments are visible only as upcoming features.
