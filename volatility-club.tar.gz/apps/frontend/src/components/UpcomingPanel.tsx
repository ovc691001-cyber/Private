export function UpcomingPanel() {
  return (
    <section className="panel">
      <div className="section-head">
        <h2>Скоро</h2>
        <span className="muted">следующие режимы</span>
      </div>
      <div className="upcoming-grid">
        <article className="upcoming-card">
          <span className="badge">Скоро</span>
          <strong>Дуэли</strong>
          <p className="muted">Собирай портфель и соревнуйся с другим игроком на короткой дистанции.</p>
          <p className="muted">Откроется для активных игроков.</p>
        </article>
        <article className="upcoming-card">
          <span className="badge">Скоро</span>
          <strong>Турниры</strong>
          <p className="muted">Ежедневный формат на длинной дистанции с рейтингом и итоговой таблицей.</p>
          <p className="muted">Откроется для активных игроков.</p>
        </article>
      </div>
    </section>
  );
}
