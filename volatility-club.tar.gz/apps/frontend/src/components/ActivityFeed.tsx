import type { ActivityItem } from "@/app/page";

export function ActivityFeed({ items }: { items: ActivityItem[] }) {
  return (
    <section className="panel">
      <div className="section-head">
        <h2>Живая активность</h2>
        <span className="muted">обновляется автоматически</span>
      </div>
      <div className="activity-list">
        {items.map((item) => (
          <div className="activity-item" key={item.id}>
            <span className={`activity-dot ${item.kind}`} />
            <span>{item.text}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
