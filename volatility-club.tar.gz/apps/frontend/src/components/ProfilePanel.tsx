import type { ProfileDetails, ReferralOverview, User } from "@/app/page";

export function ProfilePanel({
  user,
  profile,
  referral
}: {
  user: User;
  profile: ProfileDetails | null;
  referral: ReferralOverview | null;
}) {
  return (
    <section className="panel">
      <div className="section-head">
        <h2>Профиль</h2>
        <span className="muted">{user.nickname ?? user.firstName ?? user.username ?? "Игрок"}</span>
      </div>
      <div className="profile-card">
        <div className="profile-row">
          {user.photoUrl ? <img src={user.photoUrl} alt="" className="avatar" /> : <div className="avatar fallback" />}
          <div className="grow">
            <strong>{user.nickname ?? user.firstName ?? user.username ?? "Игрок"}</strong>
            <p className="muted">Баланс: {user.balance} бурмалды</p>
          </div>
        </div>
        <div className="stats-grid">
          <div>
            <span className="muted">Winrate</span>
            <strong>{profile?.winRate ?? 0}%</strong>
          </div>
          <div>
            <span className="muted">Раунды</span>
            <strong>{profile?.totalRounds ?? 0}</strong>
          </div>
          <div>
            <span className="muted">Серия</span>
            <strong>{profile?.currentStreak ?? 0}</strong>
          </div>
          <div>
            <span className="muted">Лучшая серия</span>
            <strong>{profile?.bestStreak ?? 0}</strong>
          </div>
        </div>
        <div className="referral-box">
          <strong>Рефералка</strong>
          <p className="muted">
            Код: {referral?.code ?? "—"} • Друзей: {referral?.invitedCount ?? 0}
          </p>
        </div>
      </div>
    </section>
  );
}
