type Asset = {
  id: string;
  name: string;
  volatilityType: string;
  volatilityLabel?: string;
  description?: string;
  hint?: string | null;
  chartData: Array<{ tick: number; value: number }>;
  finalReturn: number | null;
};

export function AssetCard({
  asset,
  selected,
  disabled,
  onSelect
}: {
  asset: Asset;
  selected: boolean;
  disabled: boolean;
  onSelect: () => void;
}) {
  const points = asset.chartData.length > 0 ? asset.chartData : [{ tick: 0, value: 100 }];
  const min = Math.min(...points.map((point) => point.value));
  const max = Math.max(...points.map((point) => point.value));
  const spread = Math.max(1, max - min);
  const d = points
    .map((point, index) => {
      const x = (index / Math.max(1, points.length - 1)) * 100;
      const y = 44 - ((point.value - min) / spread) * 36;
      return `${index === 0 ? "M" : "L"} ${x.toFixed(2)} ${y.toFixed(2)}`;
    })
    .join(" ");

  return (
    <button className={`asset-card ${selected ? "selected" : ""}`} disabled={disabled} onClick={onSelect}>
      <div className="asset-card-head">
        <span className="asset-name">{asset.name}</span>
        <span className="asset-pill">{asset.volatilityLabel ?? asset.volatilityType}</span>
      </div>
      <p className="muted">{asset.description ?? "Выбери актив с самым сильным ростом к финалу раунда."}</p>
      <svg viewBox="0 0 100 52" role="img" aria-label={`График ${asset.name}`}>
        <path d={d} fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      </svg>
      {asset.hint ? <p className="hint">{asset.hint}</p> : null}
      {asset.finalReturn === null ? (
        <span className="muted">Итог откроется после расчета раунда</span>
      ) : (
        <span className={asset.finalReturn >= 0 ? "positive" : "negative"}>{asset.finalReturn.toFixed(2)}%</span>
      )}
    </button>
  );
}
