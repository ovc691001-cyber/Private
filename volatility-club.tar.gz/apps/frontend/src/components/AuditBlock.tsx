type Round = {
  id: string;
  startAt: string;
  endAt: string;
  seedHash: string;
  revealedSeed: string | null;
  winningAssetId: string | null;
};

export function AuditBlock({ round }: { round: Round }) {
  return (
    <section className="panel audit">
      <div className="section-head">
        <h2>Fairness</h2>
        <span className="muted">hash • seed • verify</span>
      </div>
      <dl>
        <dt>Round</dt>
        <dd>{round.id}</dd>
        <dt>Window</dt>
        <dd>
          {new Date(round.startAt).toLocaleTimeString("ru-RU")} - {new Date(round.endAt).toLocaleTimeString("ru-RU")}
        </dd>
        <dt>Hash</dt>
        <dd>{round.seedHash}</dd>
        <dt>Seed</dt>
        <dd>{round.revealedSeed ?? "Раскроется после расчета"}</dd>
        <dt>Verify</dt>
        <dd>/rounds/{round.id}/verify</dd>
      </dl>
    </section>
  );
}
