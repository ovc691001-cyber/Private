import type { BetHistory } from "@/app/page";

export function History({ bets }: { bets: BetHistory[] }) {
  return (
    <section className="panel">
      <div className="section-head">
        <h2>История раундов</h2>
        <span className="muted">{bets.length} записей</span>
      </div>
      {bets.length === 0 ? <p className="muted">История появится после первого завершенного раунда.</p> : null}
      <div className="list">
        {bets.map((bet) => (
          <article className="history-card" key={bet.id}>
            <div className="row">
              <div>
                <strong>{bet.assetName ?? "Актив"}</strong>
                <p className="muted">{new Date(bet.placedAt).toLocaleString("ru-RU")}</p>
              </div>
              <div className="right">
                <span className={`badge ${bet.status}`}>{labelForStatus(bet.status)}</span>
                <strong>{bet.payout > 0 ? `+${bet.payout}` : `-${bet.amount}`}</strong>
              </div>
            </div>
            <div className="history-grid">
              <span>Победитель</span>
              <strong>{bet.winningAssetName ?? "Еще не определен"}</strong>
              <span>Ставка</span>
              <strong>{bet.amount} бурмалды</strong>
              <span>Seed hash</span>
              <strong>{shorten(bet.seedHash)}</strong>
              <span>Seed</span>
              <strong>{bet.revealedSeed ? shorten(bet.revealedSeed) : "После завершения"}</strong>
            </div>
            {bet.verifyPath ? <p className="muted">Verify: {bet.verifyPath}</p> : null}
          </article>
        ))}
      </div>
    </section>
  );
}

function labelForStatus(status: string) {
  if (status === "won") return "выигрыш";
  if (status === "lost") return "мимо";
  if (status === "pending") return "в игре";
  return status;
}

function shorten(value: string | null) {
  if (!value) return "-";
  return value.length > 22 ? `${value.slice(0, 22)}...` : value;
}
