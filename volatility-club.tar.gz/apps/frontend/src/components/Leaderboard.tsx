import type { LeaderboardRow } from "@/app/page";

export function Leaderboard({ rows }: { rows: LeaderboardRow[] }) {
  return (
    <section className="panel">
      <div className="section-head">
        <h2>Лидерборд дня</h2>
        <span className="muted">Топ 10</span>
      </div>
      {rows.length === 0 ? <p className="muted">Сегодня еще нет завершенных раундов.</p> : null}
      <div className="list">
        {rows.map((row, index) => (
          <div className="row leaderboard-row" key={`${row.name}-${index}`}>
            <div className="rank">{index + 1}</div>
            <div className="grow">
              <strong>{row.name}</strong>
              <p className="muted">
                Победы {row.winsCount} • Winrate {row.winRate}% • Серия {row.currentStreak}
              </p>
            </div>
            <strong className={row.score >= 0 ? "positive" : "negative"}>{row.score}</strong>
          </div>
        ))}
      </div>
    </section>
  );
}
