import type { Mission } from "@/app/page";

export function MissionsPanel({
  missions,
  busy,
  onClaim
}: {
  missions: Mission[];
  busy: boolean;
  onClaim: (missionId: Mission["id"]) => void;
}) {
  return (
    <section className="panel">
      <div className="section-head">
        <h2>Ежедневные миссии</h2>
        <span className="muted">до +300 бурмалды</span>
      </div>
      <div className="list">
        {missions.map((mission) => (
          <div className="mission-row" key={mission.id}>
            <div className="grow">
              <strong>{mission.title}</strong>
              <p className="muted">
                {mission.description} • {mission.progress}/{mission.target}
              </p>
            </div>
            <div className="right">
              <span className="mission-reward">+{mission.reward}</span>
              <button
                className="mini-button"
                disabled={busy || !mission.claimable}
                onClick={() => onClaim(mission.id)}
              >
                {mission.claimed ? "Получено" : mission.claimable ? "Забрать" : "В процессе"}
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
