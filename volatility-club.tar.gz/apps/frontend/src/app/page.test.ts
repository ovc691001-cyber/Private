import fs from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { describe, expect, it } from "vitest";

const filePath = fileURLToPath(new URL("./page.tsx", import.meta.url));
const source = fs.readFileSync(path.resolve(filePath), "utf8").toLowerCase();

describe("home screen copy", () => {
  it("keeps the burmalda-only product framing", () => {
    expect(source).toContain("бурмалды");
    expect(source).toContain("ежедневные миссии");
  });

  it("does not expose money or subscription prompts", () => {
    const forbidden = ["real money", "buy coins", "premium purchase", "subscriptions", "top up", "store"];
    for (const term of forbidden) expect(source).not.toContain(term);
  });
});
