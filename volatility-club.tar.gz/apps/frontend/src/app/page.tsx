"use client";

import { useEffect, useMemo, useState } from "react";
import { api, ApiError, clearSessionToken, saveSessionToken } from "@/lib/api";
import { getDeviceFingerprint, getTelegramInitData, setupTelegramTheme } from "@/lib/telegram";
import { AssetCard } from "@/components/AssetCard";
import { Leaderboard } from "@/components/Leaderboard";
import { History } from "@/components/History";
import { AuditBlock } from "@/components/AuditBlock";
import { ActivityFeed } from "@/components/ActivityFeed";
import { MissionsPanel } from "@/components/MissionsPanel";
import { ProfilePanel } from "@/components/ProfilePanel";
import { UpcomingPanel } from "@/components/UpcomingPanel";

export type User = {
  id: string;
  username: string | null;
  firstName: string | null;
  photoUrl: string | null;
  nickname: string | null;
  balance: number;
  rulesAcceptedAt: string | null;
  currentStreak: number;
  bestStreak: number;
};

type RoundAsset = {
  id: string;
  name: string;
  volatilityType: string;
  volatilityLabel: string;
  description: string;
  chartData: Array<{ tick: number; value: number }>;
  finalReturn: number | null;
};

type Round = {
  id: string;
  status: string;
  startAt: string;
  endAt: string;
  seedHash: string;
  revealedSeed: string | null;
  winningAssetId: string | null;
  boosts?: {
    chart: boolean;
    hint: boolean;
  };
  assets: RoundAsset[];
};

export type BetHistory = {
  id: string;
  roundId: string;
  assetName: string | null;
  winningAssetName: string | null;
  amount: number;
  status: string;
  payout: number;
  placedAt: string;
  seedHash: string | null;
  revealedSeed: string | null;
  winningAssetId: string | null;
  verifyPath: string | null;
};

export type LeaderboardRow = {
  name: string;
  photoUrl: string | null;
  betsCount: number;
  winsCount: number;
  winRate: number;
  currentStreak: number;
  netProfit: number;
  score: number;
};

export type ActivityItem = {
  id: string;
  kind: "system" | "market" | "leaderboard";
  text: string;
};

export type Mission = {
  id: "play_five_rounds" | "win_two_rounds" | "streak_two_wins";
  title: string;
  description: string;
  target: number;
  progress: number;
  reward: number;
  claimed: boolean;
  claimable: boolean;
};

export type ProfileDetails = {
  totalRounds: number;
  wins: number;
  winRate: number;
  currentStreak: number;
  bestStreak: number;
};

export type ReferralOverview = {
  code: string;
  invitedCount: number;
  items: Array<{ id: string; name: string; roundsPlayed: number; milestoneReached: boolean }>;
};

type Lobby = {
  user: { balance: number; nickname: string | null; firstName: string | null; photoUrl: string | null };
  profile: ProfileDetails;
  economy: {
    currency: string;
    betAmount: number;
    totalReturn: number;
    dailyLoginBonus: number;
    rescueAmount: number;
  };
  howToPlay: string;
  currentRound: Round;
  history: BetHistory[];
  leaderboard: LeaderboardRow[];
  activity: ActivityItem[];
  missions: Mission[];
  referral: ReferralOverview;
};

type MeResponse = {
  user: User;
  stats: ProfileDetails;
  referral: ReferralOverview;
};

type DailyLoginResponse = {
  balance: number;
  amount: number;
  claimedAt: string;
};

type RescueResponse = {
  balance: number;
  amount: number;
  nextAvailableAt: string;
};

type BoostChartResponse = {
  type: "chart";
  assets: Array<{ id: string; name: string; chartData: Array<{ tick: number; value: number }> }>;
};

type BoostHintResponse = {
  type: "hint";
  hints: Array<{ id: string; name: string; hint: string }>;
};

export default function Home() {
  const [user, setUser] = useState<User | null>(null);
  const [lobby, setLobby] = useState<Lobby | null>(null);
  const [nickname, setNickname] = useState("");
  const [rulesAccepted, setRulesAccepted] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const [chartBoostData, setChartBoostData] = useState<Record<string, Array<{ tick: number; value: number }>>>({});
  const [hintBoostData, setHintBoostData] = useState<Record<string, string>>({});

  const needsSetup = user && (!user.rulesAcceptedAt || !user.nickname);
  const round = lobby?.currentRound;
  const alreadyBet = useMemo(
    () => lobby?.history.some((bet) => bet.roundId === round?.id) ?? false,
    [lobby?.history, round?.id]
  );
  const selectedAssetBelongsToRound = Boolean(round?.assets.some((asset) => asset.id === selectedAsset));
  const secondsLeft = round ? Math.max(0, Math.ceil((new Date(round.endAt).getTime() - now) / 1000)) : 0;
  const visibleAssets = useMemo(
    () =>
      round?.assets.map((asset) => ({
        ...asset,
        chartData: chartBoostData[asset.id] ?? asset.chartData,
        hint: hintBoostData[asset.id] ?? null
      })) ?? [],
    [chartBoostData, hintBoostData, round?.assets]
  );

  useEffect(() => {
    setupTelegramTheme();
    void boot();
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!user) return;
    const handle = window.setInterval(() => {
      void refreshActivity();
    }, 4_000);
    return () => window.clearInterval(handle);
  }, [user?.id]);

  useEffect(() => {
    if (!round || round.status !== "active") return;
    const msLeft = new Date(round.endAt).getTime() - now;
    if (msLeft > 0 || loading || busy) return;
    void refreshAll();
  }, [round?.id, round?.status, round?.endAt, now, loading, busy]);

  useEffect(() => {
    setSelectedAsset(null);
    setChartBoostData({});
    setHintBoostData({});
  }, [round?.id]);

  async function boot() {
    setLoading(true);
    setError(null);
    setNotice(null);
    try {
      const initData = getTelegramInitData();
      if (initData) {
        const auth = await api<{ user: User; sessionToken: string }>("/auth/telegram", {
          method: "POST",
          body: { initData, deviceFingerprint: getDeviceFingerprint() }
        });
        saveSessionToken(auth.sessionToken);
        setUser(auth.user);
        setNickname(auth.user.nickname ?? auth.user.username ?? auth.user.firstName ?? "");
        setRulesAccepted(Boolean(auth.user.rulesAcceptedAt));
      } else {
        try {
          const me = await api<MeResponse>("/me");
          setUser(me.user);
          setNickname(me.user.nickname ?? "");
          setRulesAccepted(Boolean(me.user.rulesAcceptedAt));
        } catch {
          try {
            const dev = await api<{ user: User; sessionToken: string }>("/auth/dev", {
              method: "POST",
              body: { deviceFingerprint: getDeviceFingerprint() }
            });
            saveSessionToken(dev.sessionToken);
            setUser(dev.user);
            setNickname(dev.user.nickname ?? "");
            setRulesAccepted(Boolean(dev.user.rulesAcceptedAt));
          } catch {
            if (process.env.NODE_ENV === "production") {
              throw new ApiError(
                "Откройте приложение через кнопку Play в Telegram-боте. В обычном браузере Telegram не передает данные для входа.",
                401
              );
            }
            const demo = createDemoState();
            setUser(demo.user);
            setLobby(demo.lobby);
            setNickname(demo.user.nickname ?? "");
            setRulesAccepted(true);
            setNotice("Локальный демо-режим включен для разработки.");
            return;
          }
        }
      }
      await refreshAll();
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) clearSessionToken();
      setError(err instanceof ApiError ? err.message : "Не удалось войти. Откройте приложение внутри Telegram.");
    } finally {
      setLoading(false);
    }
  }

  async function refreshAll() {
    const [lobbyData, meData] = await Promise.all([api<Lobby>("/lobby"), api<MeResponse>("/me")]);
    setLobby(lobbyData);
    setUser(meData.user);
  }

  async function refreshActivity() {
    if (!lobby) return;
    try {
      const result = await api<{ items: ActivityItem[] }>("/activity/feed");
      setLobby((current) => (current ? { ...current, activity: result.items } : current));
    } catch {
      // keep the main flow quiet for feed polling
    }
  }

  async function saveProfile() {
    setBusy(true);
    setError(null);
    try {
      const result = await api<{ user: User }>("/me/profile", {
        method: "PATCH",
        body: { nickname, rulesAccepted, deviceFingerprint: getDeviceFingerprint() }
      });
      setUser(result.user);
      await refreshAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не удалось сохранить профиль");
    } finally {
      setBusy(false);
    }
  }

  async function placeBet() {
    if (!round || !selectedAsset) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      if (round.id === "demo-round") {
        placeDemoBet(round, selectedAsset);
        return;
      }
      await api("/bets", {
        method: "POST",
        body: { roundId: round.id, assetId: selectedAsset }
      });
      setNotice("Выбор зафиксирован. Дождись расчета модели.");
      await refreshAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Ставка не прошла");
    } finally {
      setBusy(false);
    }
  }

  async function claimDailyLogin() {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const result = await api<DailyLoginResponse>("/me/claim-daily-login", { method: "POST" });
      setNotice(`Ежедневный бонус получен: +${result.amount} бурмалды.`);
      await refreshAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не удалось получить бонус");
    } finally {
      setBusy(false);
    }
  }

  async function claimRescue() {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const result = await api<RescueResponse>("/me/claim-rescue", { method: "POST" });
      setNotice(`Rescue начислен: +${result.amount} бурмалды.`);
      await refreshAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Rescue пока недоступен");
    } finally {
      setBusy(false);
    }
  }

  async function claimMission(missionId: Mission["id"]) {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api("/me/claim-mission", { method: "POST", body: { missionId } });
      setNotice("Награда за миссию начислена.");
      await refreshAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не удалось забрать награду");
    } finally {
      setBusy(false);
    }
  }

  async function buyBoost(type: "chart" | "hint") {
    if (!round) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      if (type === "chart") {
        const result = await api<BoostChartResponse>(`/rounds/${round.id}/boosts/chart`, { method: "POST" });
        setChartBoostData(Object.fromEntries(result.assets.map((asset) => [asset.id, asset.chartData])));
        setNotice("Расширенный график открыт для этого раунда.");
      } else {
        const result = await api<BoostHintResponse>(`/rounds/${round.id}/boosts/hint`, { method: "POST" });
        setHintBoostData(Object.fromEntries(result.hints.map((item) => [item.id, item.hint])));
        setNotice("Подсказка по паттерну активирована.");
      }
      await refreshAll();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Не удалось купить буст");
    } finally {
      setBusy(false);
    }
  }

  function scrollToRound() {
    document.getElementById("round-play")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function placeDemoBet(roundToBet: Round, assetId: string) {
    const selected = roundToBet.assets.find((asset) => asset.id === assetId);
    const winner = [...roundToBet.assets].sort((a, b) => (b.finalReturn ?? -Infinity) - (a.finalReturn ?? -Infinity))[0];
    const won = winner?.id === assetId;
    const payout = won ? 270 : 0;

    setLobby((current) => {
      if (!current || !selected) return current;
      return {
        ...current,
        user: {
          ...current.user,
          balance: current.user.balance - 100 + payout
        },
        profile: {
          ...current.profile,
          totalRounds: current.profile.totalRounds + 1,
          wins: current.profile.wins + (won ? 1 : 0),
          winRate: Math.round(((current.profile.wins + (won ? 1 : 0)) / (current.profile.totalRounds + 1)) * 100),
          currentStreak: won ? current.profile.currentStreak + 1 : 0,
          bestStreak: won
            ? Math.max(current.profile.bestStreak, current.profile.currentStreak + 1)
            : current.profile.bestStreak
        },
        history: [
          {
            id: `demo-bet-${Date.now()}`,
            roundId: roundToBet.id,
            assetName: selected.name,
            winningAssetName: winner?.name ?? null,
            amount: 100,
            status: won ? "won" : "lost",
            payout,
            placedAt: new Date().toISOString(),
            seedHash: roundToBet.seedHash,
            revealedSeed: "demo-local-preview-seed",
            winningAssetId: winner?.id ?? null,
            verifyPath: `/rounds/${roundToBet.id}/verify`
          },
          ...current.history
        ].slice(0, 10),
        leaderboard: current.leaderboard.map((row, index) =>
          index === 0
            ? {
                ...row,
                betsCount: row.betsCount + 1,
                winsCount: row.winsCount + (won ? 1 : 0),
                winRate: Math.round(((row.winsCount + (won ? 1 : 0)) / (row.betsCount + 1)) * 100),
                currentStreak: won ? row.currentStreak + 1 : 0,
                netProfit: row.netProfit + payout - 100,
                score: row.score + payout - 100
              }
            : row
        )
      };
    });
    setSelectedAsset(null);
    setNotice(won ? "Демо: точный выбор, +270 бурмалды." : "Демо: раунд закрыт, в этот раз рынок ушел в другую сторону.");
  }

  if (loading) return <main className="screen center">Загрузка Volatility Club...</main>;

  if (error && !user) {
    return (
      <main className="screen center">
        <h1>Вход не удался</h1>
        <p>{error}</p>
        <button onClick={boot}>Повторить</button>
      </main>
    );
  }

  if (needsSetup && user) {
    return (
      <main className="screen">
        <section className="panel">
          <div className="profile-row">
            {user.photoUrl ? <img src={user.photoUrl} alt="" className="avatar" /> : <div className="avatar fallback" />}
            <div>
              <h1>Добро пожаловать</h1>
              <p>{user.firstName ?? user.username ?? "Игрок"}, выбери ник и прими правила игры.</p>
            </div>
          </div>
          <label className="field">
            Nickname
            <input value={nickname} onChange={(event) => setNickname(event.target.value)} placeholder="Твой ник" maxLength={24} />
          </label>
          <label className="check">
            <input type="checkbox" checked={rulesAccepted} onChange={(event) => setRulesAccepted(event.target.checked)} />
            В игре используется только виртуальная валюта бурмалда. Никаких оплат, выводов и внешних покупок здесь нет.
          </label>
          {error ? <p className="error">{error}</p> : null}
          <button disabled={busy || !rulesAccepted || nickname.trim().length < 2} onClick={saveProfile}>
            Войти в игру
          </button>
        </section>
      </main>
    );
  }

  if (!user || !lobby || !round) return null;

  return (
    <main className="screen">
      <header className="hero-card">
        <div className="profile-row">
          {user.photoUrl ? <img src={user.photoUrl} alt="" className="avatar" /> : <div className="avatar fallback" />}
          <div className="grow">
            <span className="muted">Игрок</span>
            <strong>{user.nickname ?? user.firstName ?? user.username ?? "Игрок"}</strong>
          </div>
          <div className="balance-box">
            <span className="muted">Баланс</span>
            <strong>{lobby.user.balance} бурмалды</strong>
          </div>
        </div>
      </header>

      <section className="panel">
        <div className="section-head">
          <div>
            <h2>Текущий активный раунд</h2>
            <p className="muted">{lobby.howToPlay}</p>
          </div>
          <span className="badge">{round.status}</span>
        </div>
        <div className="hero-summary">
          <div>
            <span className="muted">До финала</span>
            <strong>{formatDuration(secondsLeft)}</strong>
          </div>
          <div>
            <span className="muted">Ставка</span>
            <strong>{lobby.economy.betAmount} бурмалды</strong>
          </div>
          <div>
            <span className="muted">Точный выбор</span>
            <strong>+{lobby.economy.totalReturn}</strong>
          </div>
        </div>
        <button onClick={scrollToRound}>Сыграть</button>
      </section>

      {error ? <p className="error">{error}</p> : null}
      {notice ? <p className="notice">{notice}</p> : null}

      <div className="dashboard-grid">
        <ActivityFeed items={lobby.activity} />
        <section className="panel">
          <div className="section-head">
            <h2>Ежедневный ритм</h2>
            <span className="muted">стабильный доход для активных</span>
          </div>
          <div className="bonus-actions">
            <button className="mini-button" disabled={busy} onClick={claimDailyLogin}>
              Забрать daily +{lobby.economy.dailyLoginBonus}
            </button>
            <button className="mini-button" disabled={busy || lobby.user.balance >= 200} onClick={claimRescue}>
              Rescue +{lobby.economy.rescueAmount}
            </button>
          </div>
          <p className="muted">Daily login один раз в сутки. Rescue доступен при балансе ниже 200 и не чаще раза в 3 часа.</p>
        </section>
      </div>

      <MissionsPanel missions={lobby.missions} busy={busy} onClaim={claimMission} />

      <section className="panel" id="round-play">
        <div className="section-head">
          <div>
            <h2>Раунд</h2>
            <p className="muted">Hash seed: {round.seedHash.slice(0, 18)}...</p>
          </div>
          <button className="secondary small-button" onClick={refreshAll}>
            Обновить
          </button>
        </div>

        <div className="boost-row">
          <button className="mini-button" disabled={busy} onClick={() => buyBoost("chart")}>
            {round.boosts?.chart ? "График открыт" : "Расширенный график • 50"}
          </button>
          <button className="mini-button" disabled={busy} onClick={() => buyBoost("hint")}>
            {round.boosts?.hint ? "Подсказка активна" : "Подсказка по паттерну • 100"}
          </button>
        </div>

        <div className="asset-grid">
          {visibleAssets.map((asset) => (
            <AssetCard
              key={asset.id}
              asset={asset}
              selected={selectedAsset === asset.id}
              disabled={alreadyBet || busy}
              onSelect={() => setSelectedAsset(asset.id)}
            />
          ))}
        </div>

        <button disabled={!selectedAssetBelongsToRound || busy || alreadyBet} onClick={placeBet}>
          {alreadyBet ? "Выбор уже зафиксирован" : `Подтвердить ставку ${lobby.economy.betAmount} бурмалды`}
        </button>
        {alreadyBet ? (
          <p className="muted">В одном раунде доступен только один выбор. Следующий откроется после расчета модели.</p>
        ) : null}
      </section>

      <History bets={lobby.history} />
      <Leaderboard rows={lobby.leaderboard} />
      <UpcomingPanel />
      <ProfilePanel user={user} profile={lobby.profile} referral={lobby.referral} />
      <AuditBlock round={round} />
    </main>
  );
}

function formatDuration(totalSeconds: number): string {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

function createDemoState(): { user: User; lobby: Lobby } {
  const now = new Date();
  const round: Round = {
    id: "demo-round",
    status: "active",
    startAt: now.toISOString(),
    endAt: new Date(now.getTime() + 240_000).toISOString(),
    seedHash: "demo8f5c3c0b1b7a8a2c9f9d4e1a6f2c3b8d7e4f1a0c9b2e8d5f7a1c4b9e0d6",
    revealedSeed: null,
    winningAssetId: null,
    boosts: { chart: false, hint: false },
    assets: [
      {
        id: "demo-nova",
        name: "NOVA",
        volatilityType: "trend",
        volatilityLabel: "Направленный",
        description: "Может держать движение дольше, чем кажется по первым тикам.",
        chartData: [
          { tick: 0, value: 99.8 },
          { tick: 1, value: 100.6 },
          { tick: 2, value: 101.2 },
          { tick: 3, value: 101.9 },
          { tick: 4, value: 102.5 }
        ],
        finalReturn: 4.8
      },
      {
        id: "demo-quartz",
        name: "QUARTZ",
        volatilityType: "spiky",
        volatilityLabel: "Импульсный",
        description: "Любит резкие ускорения и откаты на короткой дистанции.",
        chartData: [
          { tick: 0, value: 100.5 },
          { tick: 1, value: 98.9 },
          { tick: 2, value: 102.8 },
          { tick: 3, value: 99.7 },
          { tick: 4, value: 101.1 }
        ],
        finalReturn: 1.1
      },
      {
        id: "demo-pulse",
        name: "PULSE",
        volatilityType: "mean-revert",
        volatilityLabel: "Возвратный",
        description: "После всплеска часто возвращается ближе к среднему уровню.",
        chartData: [
          { tick: 0, value: 100.1 },
          { tick: 1, value: 99.4 },
          { tick: 2, value: 98.7 },
          { tick: 3, value: 99.2 },
          { tick: 4, value: 98.1 }
        ],
        finalReturn: -1.9
      }
    ]
  };

  const user: User = {
    id: "demo-user",
    username: "local_demo",
    firstName: "Local",
    photoUrl: null,
    nickname: "local_player",
    balance: 1000,
    rulesAcceptedAt: now.toISOString(),
    currentStreak: 1,
    bestStreak: 3
  };

  return {
    user,
    lobby: {
      user: { balance: 1000, nickname: "local_player", firstName: "Local", photoUrl: null },
      profile: { totalRounds: 12, wins: 5, winRate: 42, currentStreak: 1, bestStreak: 3 },
      economy: {
        currency: "бурмалда",
        betAmount: 100,
        totalReturn: 270,
        dailyLoginBonus: 200,
        rescueAmount: 200
      },
      howToPlay: "Выбери актив, который покажет лучший рост.",
      currentRound: round,
      history: [
        {
          id: "demo-bet-1",
          roundId: "demo-old-round",
          assetName: "NOVA",
          winningAssetName: "NOVA",
          amount: 100,
          status: "won",
          payout: 270,
          placedAt: new Date(now.getTime() - 3_600_000).toISOString(),
          seedHash: "demo-history-hash",
          revealedSeed: "demo-history-seed",
          winningAssetId: "demo-nova",
          verifyPath: "/rounds/demo-old-round/verify"
        }
      ],
      leaderboard: [
        { name: "local_player", photoUrl: null, betsCount: 7, winsCount: 4, winRate: 57, currentStreak: 3, netProfit: 280, score: 280 },
        { name: "vola_cat", photoUrl: null, betsCount: 5, winsCount: 2, winRate: 40, currentStreak: 1, netProfit: 70, score: 70 },
        { name: "risk_zero", photoUrl: null, betsCount: 6, winsCount: 2, winRate: 33, currentStreak: 0, netProfit: -130, score: -130 }
      ],
      activity: [
        { id: "demo-1", kind: "system", text: "В этом раунде сделано выборов: 9" },
        { id: "demo-2", kind: "market", text: "Популярный актив раунда: NOVA" },
        { id: "demo-3", kind: "market", text: "Последний результат: +170 бурмалды" },
        { id: "demo-4", kind: "leaderboard", text: "Серия побед у лидера: 3" },
        { id: "demo-5", kind: "system", text: "Новый раунд стартует сразу после расчета текущего." }
      ],
      missions: [
        {
          id: "play_five_rounds",
          title: "Сыграй 5 раундов",
          description: "Проведи пять раундов за текущие сутки.",
          target: 5,
          progress: 3,
          reward: 100,
          claimed: false,
          claimable: false
        },
        {
          id: "win_two_rounds",
          title: "Выиграй 2 раунда",
          description: "Возьми два точных прогноза за сутки.",
          target: 2,
          progress: 1,
          reward: 100,
          claimed: false,
          claimable: false
        },
        {
          id: "streak_two_wins",
          title: "Собери серию из 2 побед",
          description: "Держи серию побед и забери бонус.",
          target: 2,
          progress: 1,
          reward: 100,
          claimed: false,
          claimable: false
        }
      ],
      referral: {
        code: "ref_123456789",
        invitedCount: 2,
        items: [
          { id: "r1", name: "moon_reader", roundsPlayed: 4, milestoneReached: true },
          { id: "r2", name: "quartz_seed", roundsPlayed: 1, milestoneReached: false }
        ]
      }
    }
  };
}
