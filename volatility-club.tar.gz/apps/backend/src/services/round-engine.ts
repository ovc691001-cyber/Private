import { sha256Hex } from "../utils/crypto.js";

export type RoundEngineConfig = {
  assetCount: number;
  ticks: number;
  durationSeconds: number;
  betAmount: number;
  payoutMultiplier: number;
};

export type EngineAsset = {
  engineId: number;
  name: string;
  volatilityType: string;
  chartData: { tick: number; value: number }[];
  finalReturn: number;
};

export type EngineRoundResult = {
  seedHash: string;
  assets: EngineAsset[];
  winningEngineId: number;
};

const assetNames = ["NOVA", "QUARTZ", "PULSE", "EMBER", "ORBIT", "MINT"];
const archetypes = [
  { name: "calm", drift: 0.15, amplitude: 1.4 },
  { name: "spiky", drift: 0.05, amplitude: 4.2 },
  { name: "mean-revert", drift: -0.05, amplitude: 2.5 },
  { name: "trend", drift: 0.45, amplitude: 2.1 }
];

function xmur3(str: string): () => number {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i += 1) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return () => {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    return (h ^= h >>> 16) >>> 0;
  };
}

function mulberry32(seed: number): () => number {
  return () => {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function deterministicRandom(seed: string): () => number {
  return mulberry32(xmur3(seed)());
}

function round6(value: number): number {
  return Math.round(value * 1_000_000) / 1_000_000;
}

export function generateRoundFromSeed(seed: string, config: RoundEngineConfig): EngineRoundResult {
  const random = deterministicRandom(seed);
  const assets: EngineAsset[] = [];

  for (let index = 0; index < config.assetCount; index += 1) {
    const archetype = archetypes[Math.floor(random() * archetypes.length)] ?? archetypes[0]!;
    const name = assetNames[index] ?? `ASSET-${index + 1}`;
    let value = 100 + (random() - 0.5) * 3;
    const chartData = [];

    for (let tick = 0; tick < config.ticks; tick += 1) {
      const shock = (random() - 0.5) * archetype.amplitude;
      const wobble = Math.sin((tick + 1) * (index + 1)) * 0.25;
      value = Math.max(1, value + archetype.drift + shock + wobble);
      chartData.push({ tick, value: round6(value) });
    }

    const finalReturn = round6(((value - 100) / 100) * 100);
    assets.push({
      engineId: index,
      name,
      volatilityType: archetype.name,
      chartData,
      finalReturn
    });
  }

  const winning = [...assets].sort((a, b) => b.finalReturn - a.finalReturn || a.engineId - b.engineId)[0]!;
  return {
    seedHash: sha256Hex(seed),
    assets,
    winningEngineId: winning.engineId
  };
}

export function verifyRound(seed: string, config: RoundEngineConfig): EngineRoundResult {
  return generateRoundFromSeed(seed, config);
}
