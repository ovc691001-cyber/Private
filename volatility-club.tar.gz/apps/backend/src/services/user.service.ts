import { Prisma, PrismaClient } from "@prisma/client";
import { config } from "../config.js";
import { badRequest } from "../lib/errors.js";
import { dayStartUtc } from "../utils/time.js";
import { applyBalanceChange, dateKey } from "./economy.service.js";

type Db = PrismaClient | Prisma.TransactionClient;

export function publicUser(user: {
  id: string;
  telegramUserId: string;
  username: string | null;
  firstName: string | null;
  photoUrl: string | null;
  nickname: string | null;
  balance: number;
  status: string;
  rulesAcceptedAt: Date | null;
  currentStreak?: number;
  bestStreak?: number;
}) {
  return {
    id: user.id,
    telegramUserId: user.telegramUserId,
    username: user.username,
    firstName: user.firstName,
    photoUrl: user.photoUrl,
    nickname: user.nickname,
    balance: user.balance,
    status: user.status,
    rulesAcceptedAt: user.rulesAcceptedAt?.toISOString() ?? null,
    currentStreak: user.currentStreak ?? 0,
    bestStreak: user.bestStreak ?? 0
  };
}

export async function getProfile(db: Db, userId: string, now = new Date()) {
  const [user, totals] = await Promise.all([
    db.user.findUniqueOrThrow({ where: { id: userId } }),
    db.bet.aggregate({
      where: { userId, settledAt: { not: null } },
      _count: { _all: true }
    })
  ]);

  const wins = await db.bet.count({
    where: { userId, status: "won", settledAt: { not: null } }
  });

  const referralCode = `ref_${user.telegramUserId}`;
  const referrals = await db.user.findMany({
    where: { referredByUserId: userId },
    select: { id: true, nickname: true, username: true, firstName: true }
  });

  const totalRounds = totals._count._all;
  return {
    user: publicUser(user),
    stats: {
      totalRounds,
      wins,
      winRate: totalRounds === 0 ? 0 : Math.round((wins / totalRounds) * 100),
      currentStreak: user.currentStreak,
      bestStreak: user.bestStreak
    },
    referral: {
      code: referralCode,
      link: null,
      invitedCount: referrals.length,
      invited: referrals.map((referral) => ({
        id: referral.id,
        name: referral.nickname ?? referral.username ?? referral.firstName ?? "Игрок"
      }))
    },
    today: {
      date: dateKey(now)
    }
  };
}

export async function claimDailyLoginBonus(db: Db, userId: string, now = new Date()) {
  const key = `daily_login:${userId}:${dateKey(now)}`;
  const existing = await db.transaction.findUnique({ where: { idempotencyKey: key } });
  if (existing) throw badRequest("Бонус за вход уже получен сегодня");

  const updated = await applyBalanceChange(db, {
    userId,
    delta: config.DAILY_LOGIN_BONUS_AMOUNT,
    type: "daily_login_bonus",
    referenceType: "user",
    referenceId: userId,
    idempotencyKey: key
  });

  return {
    balance: updated.balance,
    amount: config.DAILY_LOGIN_BONUS_AMOUNT,
    claimedAt: now.toISOString()
  };
}

export async function claimRescueRefill(db: Db, userId: string, now = new Date()) {
  const user = await db.user.findUniqueOrThrow({ where: { id: userId } });
  const lastClaim = await db.transaction.findFirst({
    where: { userId, type: "rescue_refill" },
    orderBy: { createdAt: "desc" }
  });

  if (!canClaimRescue(user.balance, lastClaim?.createdAt ?? null, now)) {
    throw badRequest("Rescue доступен только при низком балансе");
  }

  const updated = await applyBalanceChange(db, {
    userId,
    delta: config.RESCUE_REFILL_AMOUNT,
    type: "rescue_refill",
    referenceType: "user",
    referenceId: userId,
    idempotencyKey: `rescue_refill:${userId}:${now.toISOString()}`
  });

  return {
    balance: updated.balance,
    amount: config.RESCUE_REFILL_AMOUNT,
    nextAvailableAt: new Date(now.getTime() + config.RESCUE_REFILL_COOLDOWN_HOURS * 3_600_000).toISOString()
  };
}

export function canClaimRescue(balance: number, lastClaimAt: Date | null, now = new Date()) {
  if (balance >= config.RESCUE_REFILL_THRESHOLD) return false;
  if (!lastClaimAt) return true;
  return now.getTime() - lastClaimAt.getTime() >= config.RESCUE_REFILL_COOLDOWN_HOURS * 3_600_000;
}

export async function getTodayBetSummary(db: Db, userId: string, now = new Date()) {
  const start = dayStartUtc(now);
  const end = new Date(start.getTime() + 24 * 3_600_000);
  const [plays, wins] = await Promise.all([
    db.bet.count({ where: { userId, settledAt: { gte: start, lt: end } } }),
    db.bet.count({ where: { userId, status: "won", settledAt: { gte: start, lt: end } } })
  ]);

  return { plays, wins };
}
