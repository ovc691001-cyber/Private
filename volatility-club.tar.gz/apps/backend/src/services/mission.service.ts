import { Prisma, PrismaClient } from "@prisma/client";
import { MissionId } from "@volatility/shared";
import { config } from "../config.js";
import { badRequest } from "../lib/errors.js";
import { dateKey } from "./economy.service.js";
import { getTodayBetSummary } from "./user.service.js";
import { applyBalanceChange } from "./economy.service.js";

type Db = PrismaClient | Prisma.TransactionClient;

const missionCatalog: Record<
  MissionId,
  { title: string; target: number; reward: number; description: string }
> = {
  play_five_rounds: {
    title: "Сыграй 5 раундов",
    target: 5,
    reward: config.MISSION_REWARD_AMOUNT,
    description: "Проведи пять раундов за текущие сутки."
  },
  win_two_rounds: {
    title: "Выиграй 2 раунда",
    target: 2,
    reward: config.MISSION_REWARD_AMOUNT,
    description: "Возьми два точных прогноза за сутки."
  },
  streak_two_wins: {
    title: "Собери серию из 2 побед",
    target: 2,
    reward: config.MISSION_REWARD_AMOUNT,
    description: "Держи серию побед и забери бонус."
  }
};

export function missionRewardKey(userId: string, missionId: MissionId, now = new Date()) {
  return `mission_reward:${userId}:${missionId}:${dateKey(now)}`;
}

export async function getMissionBoard(db: Db, userId: string, now = new Date()) {
  const [summary, user, claimed] = await Promise.all([
    getTodayBetSummary(db, userId, now),
    db.user.findUniqueOrThrow({ where: { id: userId } }),
    db.transaction.findMany({
      where: {
        userId,
        type: "mission_reward",
        createdAt: { gte: new Date(`${dateKey(now)}T00:00:00.000Z`) }
      },
      select: { idempotencyKey: true }
    })
  ]);

  const claimedSet = new Set(claimed.map((item) => item.idempotencyKey).filter(Boolean));

  return (Object.entries(missionCatalog) as Array<[MissionId, (typeof missionCatalog)[MissionId]]>).map(([id, mission]) => {
    const progress =
      id === "play_five_rounds" ? summary.plays : id === "win_two_rounds" ? summary.wins : user.currentStreak;
    const claimKey = missionRewardKey(userId, id, now);
    return {
      id,
      title: mission.title,
      description: mission.description,
      target: mission.target,
      progress: Math.min(progress, mission.target),
      reward: mission.reward,
      claimed: claimedSet.has(claimKey),
      claimable: progress >= mission.target && !claimedSet.has(claimKey)
    };
  });
}

export async function claimMissionReward(db: Db, userId: string, missionId: MissionId, now = new Date()) {
  const mission = missionCatalog[missionId];
  if (!mission) throw badRequest("Mission not found");

  const board = await getMissionBoard(db, userId, now);
  const current = board.find((item) => item.id === missionId);
  if (!current) throw badRequest("Mission not found");
  if (current.claimed) throw badRequest("Награда уже получена");
  if (!current.claimable) throw badRequest("Миссия еще не выполнена");

  const updated = await applyBalanceChange(db, {
    userId,
    delta: mission.reward,
    type: "mission_reward",
    referenceType: "mission",
    referenceId: missionId,
    idempotencyKey: missionRewardKey(userId, missionId, now)
  });

  return {
    missionId,
    reward: mission.reward,
    balance: updated.balance
  };
}
