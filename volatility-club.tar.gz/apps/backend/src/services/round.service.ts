import { Prisma, PrismaClient, RoundStatus } from "@prisma/client";
import { roundConfig } from "../config.js";
import { badRequest } from "../lib/errors.js";
import { generateSeed, sha256Hex } from "../utils/crypto.js";
import { addSeconds } from "../utils/time.js";
import { applyBalanceChange } from "./economy.service.js";
import { maybeAwardReferralMilestone } from "./referral.service.js";
import { generateRoundFromSeed, verifyRound } from "./round-engine.js";

type Db = PrismaClient | Prisma.TransactionClient;

export async function ensureCurrentRound(db: Db, now = new Date()) {
  const active = await db.round.findFirst({
    where: {
      status: RoundStatus.active,
      startAt: { lte: now },
      endAt: { gt: now }
    },
    include: { assets: true },
    orderBy: { startAt: "desc" }
  });
  if (active) return active;

  const seed = generateSeed();
  const engine = generateRoundFromSeed(seed, roundConfig);
  const startAt = now;
  const endAt = addSeconds(startAt, roundConfig.durationSeconds);

  return db.round.create({
    data: {
      status: RoundStatus.active,
      startAt,
      endAt,
      seedHash: sha256Hex(seed),
      seedSecret: seed,
      configJson: roundConfig,
      revealedSeed: null,
      assets: {
        create: engine.assets.map((asset) => ({
          name: asset.name,
          volatilityType: asset.volatilityType,
          chartDataJson: asset.chartData,
          finalReturn: asset.finalReturn
        }))
      }
    },
    include: { assets: true }
  });
}

export function serializeRound(round: Awaited<ReturnType<typeof ensureCurrentRound>>) {
  const revealFullResult = round.status === "finished" || Boolean(round.revealedSeed);
  const durationMs = Math.max(1, round.endAt.getTime() - round.startAt.getTime());
  const elapsedRatio = Math.min(1, Math.max(0, (Date.now() - round.startAt.getTime()) / durationMs));

  return {
    id: round.id,
    status: round.status,
    roundType: round.roundType,
    startAt: round.startAt.toISOString(),
    endAt: round.endAt.toISOString(),
    seedHash: round.seedHash,
    revealedSeed: round.revealedSeed,
    winningAssetId: round.winningAssetId,
    config: round.configJson,
    settledAt: round.settledAt?.toISOString() ?? null,
    assets: round.assets.map((asset) => ({
      id: asset.id,
      name: asset.name,
      volatilityType: asset.volatilityType,
      volatilityLabel: volatilityLabel(asset.volatilityType),
      description: assetDescription(asset.volatilityType),
      chartData: visibleChartData(asset.chartDataJson, elapsedRatio, revealFullResult),
      finalReturn: revealFullResult ? Number(asset.finalReturn) : null
    }))
  };
}

function visibleChartData(chartDataJson: unknown, elapsedRatio: number, revealFullResult: boolean) {
  const chartData = Array.isArray(chartDataJson) ? chartDataJson : [];
  if (revealFullResult) return chartData;
  const visibleCount = Math.max(
    1,
    Math.min(roundConfig.publicTicks, Math.ceil(chartData.length * elapsedRatio))
  );
  return chartData.slice(0, visibleCount);
}

export async function settleDueRounds(db: PrismaClient, now = new Date()): Promise<number> {
  const rounds = await db.round.findMany({
    where: { status: RoundStatus.active, endAt: { lte: now } },
    include: { assets: true, bets: true }
  });

  for (const round of rounds) {
    await db.$transaction(async (tx) => {
      const locked = await tx.round.findUniqueOrThrow({
        where: { id: round.id },
        include: { assets: true, bets: true }
      });
      if (locked.status !== RoundStatus.active) return;

      const seed = locked.seedSecret;
      const engine = verifyRound(seed, locked.configJson as typeof roundConfig);
      const sortedAssets = [...locked.assets].sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
      const winningAsset = sortedAssets[engine.winningEngineId];
      if (!winningAsset) throw badRequest("Winning asset cannot be resolved");

      for (const bet of locked.bets) {
        if (bet.status !== "pending") continue;
        const won = bet.assetId === winningAsset.id;
        const payout = won ? Math.floor(bet.amount * roundConfig.payoutMultiplier) : 0;
        const user = await tx.user.findUniqueOrThrow({ where: { id: bet.userId } });
        const updated = won
          ? await applyBalanceChange(tx, {
              userId: user.id,
              delta: payout,
              type: "bet_win",
              referenceType: "bet",
              referenceId: bet.id,
              idempotencyKey: `bet_win:${bet.id}`
            })
          : user;

        await tx.bet.update({
          where: { id: bet.id },
          data: { status: won ? "won" : "lost", payout, settledAt: now }
        });

        await tx.user.update({
          where: { id: user.id },
          data: won
            ? {
                currentStreak: { increment: 1 },
                bestStreak: Math.max(user.bestStreak, user.currentStreak + 1)
              }
            : {
                currentStreak: 0
              }
        });

        const date = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
        await tx.leaderboardDaily.upsert({
          where: { userId_date: { userId: user.id, date } },
          create: {
            userId: user.id,
            date,
            betsCount: 1,
            winsCount: won ? 1 : 0,
            totalWagered: bet.amount,
            totalPayout: payout,
            netProfit: payout - bet.amount
          },
          update: {
            betsCount: { increment: 1 },
            winsCount: { increment: won ? 1 : 0 },
            totalWagered: { increment: bet.amount },
            totalPayout: { increment: payout },
            netProfit: { increment: payout - bet.amount }
          }
        });

        await maybeAwardReferralMilestone(tx, user.id);
      }

      await tx.round.update({
        where: { id: locked.id },
        data: {
          status: RoundStatus.finished,
          revealedSeed: seed,
          seedHash: sha256Hex(seed),
          winningAssetId: winningAsset.id,
          settledAt: now
        }
      });
    });
  }

  return rounds.length;
}

function volatilityLabel(type: string) {
  switch (type) {
    case "trend":
      return "Направленный";
    case "spiky":
      return "Импульсный";
    case "mean-revert":
      return "Возвратный";
    default:
      return "Спокойный";
  }
}

function assetDescription(type: string) {
  switch (type) {
    case "trend":
      return "Может держать движение дольше, чем кажется по первым тикам.";
    case "spiky":
      return "Любит резкие ускорения и откаты на короткой дистанции.";
    case "mean-revert":
      return "После всплеска часто возвращается ближе к среднему уровню.";
    default:
      return "Чаще показывает плавный ход без резких скачков.";
  }
}
