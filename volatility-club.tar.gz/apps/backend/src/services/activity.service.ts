import { PrismaClient } from "@prisma/client";
import { dayStartUtc } from "../utils/time.js";

export type ActivityFeedItem = {
  id: string;
  kind: "system" | "market" | "leaderboard";
  text: string;
};

export async function getActivityFeed(db: PrismaClient, now = new Date()): Promise<ActivityFeedItem[]> {
  const start = dayStartUtc(now);
  const currentRound = await db.round.findFirst({
    where: { status: "active" },
    include: { assets: true, bets: true },
    orderBy: { startAt: "desc" }
  });

  const topLeader = await db.leaderboardDaily.findFirst({
    where: { date: start },
    include: { user: true },
    orderBy: [{ netProfit: "desc" }, { winsCount: "desc" }]
  });

  const latestBet = await db.bet.findFirst({
    where: { settledAt: { not: null } },
    include: { round: true, asset: true },
    orderBy: { settledAt: "desc" }
  });

  const items: ActivityFeedItem[] = [];

  if (currentRound) {
    items.push({
      id: `choices:${currentRound.id}`,
      kind: "system",
      text: `В этом раунде сделано выборов: ${currentRound.bets.length}`
    });

    const counts = new Map<string, number>();
    for (const bet of currentRound.bets) {
      counts.set(bet.assetId, (counts.get(bet.assetId) ?? 0) + 1);
    }

    const mostPicked = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];
    if (mostPicked) {
      const asset = currentRound.assets.find((candidate) => candidate.id === mostPicked[0]);
      if (asset) {
        items.push({
          id: `popular:${currentRound.id}`,
          kind: "market",
          text: `Популярный актив раунда: ${asset.name}`
        });
      }
    }

    const timeLeft = Math.max(0, Math.ceil((currentRound.endAt.getTime() - now.getTime()) / 1000));
    items.push({
      id: `timer:${currentRound.id}`,
      kind: "system",
      text: `Новый раунд стартует сразу после расчета. До финала: ${formatDuration(timeLeft)}`
    });
  }

  if (latestBet) {
    const delta = latestBet.payout - latestBet.amount;
    items.push({
      id: `result:${latestBet.id}`,
      kind: "market",
      text: `Последний результат: ${delta >= 0 ? "+" : ""}${delta} бурмалды`
    });
  }

  if (topLeader) {
    items.push({
      id: `leader:${topLeader.userId}`,
      kind: "leaderboard",
      text: `Серия побед у лидера: ${topLeader.user.currentStreak}`
    });
  }

  if (items.length < 5) {
    items.push({
      id: `system:${dateSeed(now)}`,
      kind: "system",
      text: "Модель обновила карту волатильности для следующего окна."
    });
  }

  return items.slice(0, 5);
}

export function isActivityFeedItem(item: ActivityFeedItem) {
  return Boolean(item.id && item.text && ["system", "market", "leaderboard"].includes(item.kind));
}

function formatDuration(totalSeconds: number): string {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

function dateSeed(now: Date) {
  return now.toISOString().slice(0, 16);
}
