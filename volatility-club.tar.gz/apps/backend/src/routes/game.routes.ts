import { historyQuerySchema, leaderboardQuerySchema, placeBetSchema } from "@volatility/shared";
import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { badRequest } from "../lib/errors.js";
import { requireAuth, requireInternalSecret } from "../middleware/auth.js";
import { actionLimiter, activityLimiter, betLimiter, leaderboardLimiter } from "../middleware/rate-limits.js";
import { validateBody, validateQuery } from "../middleware/validate.js";
import { getActivityFeed } from "../services/activity.service.js";
import { purchaseChartBoost, purchaseHintBoost, getBoostState } from "../services/boost.service.js";
import { placeBet } from "../services/bet.service.js";
import { getMissionBoard } from "../services/mission.service.js";
import { getReferralOverview } from "../services/referral.service.js";
import { ensureCurrentRound, serializeRound, settleDueRounds } from "../services/round.service.js";
import { getProfile } from "../services/user.service.js";
import { dayStartUtc } from "../utils/time.js";
import { roundConfig, config } from "../config.js";
import { verifyRound } from "../services/round-engine.js";
import { withJobLock } from "../services/job-lock.service.js";

export const gameRouter = Router();

gameRouter.get("/lobby", requireAuth, async (req, res) => {
  await settleDueRounds(prisma);
  const userId = req.user!.id;

  const round = await ensureCurrentRound(prisma);
  const [profile, history, leaderboard, activity, missions, referral, boostState] = await Promise.all([
    getProfile(prisma, userId),
    prisma.bet.findMany({
      where: { userId },
      include: {
        asset: true,
        round: {
          select: {
            winningAssetId: true,
            seedHash: true,
            revealedSeed: true,
            startAt: true,
            endAt: true,
            assets: { select: { id: true, name: true } }
          }
        }
      },
      orderBy: { placedAt: "desc" },
      take: 10
    }),
    prisma.leaderboardDaily.findMany({
      where: { date: dayStartUtc() },
      include: { user: true },
      orderBy: [{ netProfit: "desc" }, { winsCount: "desc" }],
      take: 10
    }),
    getActivityFeed(prisma),
    getMissionBoard(prisma, userId),
    getReferralOverview(prisma, userId),
    getBoostState(prisma, userId, round.id)
  ]);

  res.json({
    user: {
      balance: profile.user.balance,
      nickname: profile.user.nickname,
      firstName: profile.user.firstName,
      photoUrl: profile.user.photoUrl
    },
    profile: profile.stats,
    economy: {
      currency: "бурмалда",
      betAmount: roundConfig.betAmount,
      totalReturn: Math.floor(roundConfig.betAmount * roundConfig.payoutMultiplier),
      dailyLoginBonus: config.DAILY_LOGIN_BONUS_AMOUNT,
      rescueAmount: config.RESCUE_REFILL_AMOUNT
    },
    howToPlay: "Выбери актив, который покажет лучший рост.",
    currentRound: {
      ...serializeRound(round),
      boosts: boostState
    },
    history: history.map(serializeBet),
    leaderboard: leaderboard.map(serializeLeaderboardRow),
    activity,
    missions,
    referral
  });
});

gameRouter.get("/activity/feed", requireAuth, activityLimiter, async (_req, res) => {
  res.json({ items: await getActivityFeed(prisma) });
});

gameRouter.get("/rounds/current", requireAuth, async (req, res) => {
  await settleDueRounds(prisma);
  const round = await ensureCurrentRound(prisma);
  const boosts = await getBoostState(prisma, req.user!.id, round.id);
  res.json({ round: { ...serializeRound(round), boosts } });
});

gameRouter.get("/rounds/:id", requireAuth, async (req, res) => {
  const round = await prisma.round.findUnique({ where: { id: req.params.id }, include: { assets: true } });
  if (!round) throw badRequest("Round not found");
  const boosts = await getBoostState(prisma, req.user!.id, round.id);
  res.json({ round: { ...serializeRound(round), boosts } });
});

gameRouter.get("/rounds/:id/verify", requireAuth, async (req, res) => {
  const round = await prisma.round.findUnique({ where: { id: req.params.id }, include: { assets: true } });
  if (!round) throw badRequest("Round not found");
  if (!round.revealedSeed) {
    return res.json({ ready: false, seedHash: round.seedHash, message: "Seed will be revealed after settlement" });
  }
  const recalculated = verifyRound(round.revealedSeed, round.configJson as typeof roundConfig);
  res.json({
    ready: true,
    roundId: round.id,
    seed: round.revealedSeed,
    seedHash: round.seedHash,
    recalculated,
    stored: serializeRound(round)
  });
});

gameRouter.post("/rounds/:id/boosts/chart", requireAuth, actionLimiter, async (req, res) => {
  if (!req.params.id) throw badRequest("Round not found");
  const result = await purchaseChartBoost(prisma, req.user!.id, req.params.id);
  res.status(201).json(result);
});

gameRouter.post("/rounds/:id/boosts/hint", requireAuth, actionLimiter, async (req, res) => {
  if (!req.params.id) throw badRequest("Round not found");
  const result = await purchaseHintBoost(prisma, req.user!.id, req.params.id);
  res.status(201).json(result);
});

gameRouter.post("/bets", requireAuth, betLimiter, validateBody(placeBetSchema), async (req, res) => {
  const bet = await placeBet(prisma, req.user!.id, req.body);
  res.status(201).json({
    bet: {
      id: bet.id,
      roundId: bet.roundId,
      assetId: bet.assetId,
      assetName: bet.asset?.name ?? null,
      winningAssetName: null,
      amount: bet.amount,
      status: bet.status,
      payout: bet.payout,
      placedAt: bet.placedAt.toISOString(),
      settledAt: bet.settledAt?.toISOString() ?? null,
      winningAssetId: bet.round?.winningAssetId ?? null,
      seedHash: bet.round?.seedHash ?? null,
      revealedSeed: bet.round?.revealedSeed ?? null,
      verifyPath: `/rounds/${bet.roundId}/verify`
    }
  });
});

gameRouter.get("/bets/history", requireAuth, validateQuery(historyQuerySchema), async (req, res) => {
  const bets = await prisma.bet.findMany({
    where: { userId: req.user!.id },
    include: {
      asset: true,
      round: {
        select: {
          winningAssetId: true,
          seedHash: true,
          revealedSeed: true,
          startAt: true,
          endAt: true,
          assets: { select: { id: true, name: true } }
        }
      }
    },
    orderBy: { placedAt: "desc" },
    take: Number(req.query.limit)
  });
  res.json({ bets: bets.map(serializeBet) });
});

gameRouter.get("/leaderboard/daily", requireAuth, leaderboardLimiter, validateQuery(leaderboardQuerySchema), async (req, res) => {
  const date = req.query.date ? new Date(`${req.query.date}T00:00:00.000Z`) : dayStartUtc();
  const rows = await prisma.leaderboardDaily.findMany({
    where: { date },
    include: { user: true },
    orderBy: [{ netProfit: "desc" }, { winsCount: "desc" }],
    take: 10
  });
  res.json({ date: date.toISOString().slice(0, 10), rows: rows.map(serializeLeaderboardRow) });
});

gameRouter.get("/referral", requireAuth, async (req, res) => {
  res.json(await getReferralOverview(prisma, req.user!.id));
});

gameRouter.post("/internal/rounds/tick", requireInternalSecret, async (_req, res) => {
  const result = await withJobLock("rounds_tick", 55_000, async () => {
    const settled = await settleDueRounds(prisma);
    const current = await ensureCurrentRound(prisma);
    return { settled, currentRoundId: current.id };
  });
  res.json(result ?? { skipped: true });
});

function serializeBet(bet: {
  id: string;
  roundId: string;
  assetId: string;
  amount: number;
  status: string;
  payout: number;
  placedAt: Date;
  settledAt: Date | null;
  asset?: { name: string } | null;
  round?: {
    winningAssetId: string | null;
    seedHash: string;
    revealedSeed: string | null;
    startAt: Date;
    endAt: Date;
    assets?: Array<{ id: string; name: string }>;
  } | null;
}) {
  const winningAssetName =
    bet.round?.assets?.find((asset) => asset.id === bet.round?.winningAssetId)?.name ?? null;

  return {
    id: bet.id,
    roundId: bet.roundId,
    assetId: bet.assetId,
    assetName: bet.asset?.name ?? null,
    winningAssetName,
    amount: bet.amount,
    status: bet.status,
    payout: bet.payout,
    placedAt: bet.placedAt.toISOString(),
    settledAt: bet.settledAt?.toISOString() ?? null,
    winningAssetId: bet.round?.winningAssetId ?? null,
    seedHash: bet.round?.seedHash ?? null,
    revealedSeed: bet.round?.revealedSeed ?? null,
    verifyPath: bet.roundId ? `/rounds/${bet.roundId}/verify` : null,
    startAt: bet.round?.startAt.toISOString() ?? null,
    endAt: bet.round?.endAt.toISOString() ?? null
  };
}

function serializeLeaderboardRow(row: {
  user: { nickname: string | null; username: string | null; firstName: string | null; photoUrl: string | null; currentStreak?: number };
  betsCount: number;
  winsCount: number;
  totalWagered: number;
  totalPayout: number;
  netProfit: number;
}) {
  return {
    name: row.user.nickname ?? row.user.username ?? row.user.firstName ?? "Игрок",
    photoUrl: row.user.photoUrl,
    betsCount: row.betsCount,
    winsCount: row.winsCount,
    winRate: row.betsCount === 0 ? 0 : Math.round((row.winsCount / row.betsCount) * 100),
    currentStreak: row.user.currentStreak ?? 0,
    totalWagered: row.totalWagered,
    totalPayout: row.totalPayout,
    netProfit: row.netProfit,
    score: row.netProfit
  };
}
