import fs from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { isActivityFeedItem } from "../src/services/activity.service.js";
import { canPurchaseBoost } from "../src/services/boost.service.js";
import { missionRewardKey } from "../src/services/mission.service.js";
import { parseReferralCode } from "../src/services/referral.service.js";
import { canClaimRescue } from "../src/services/user.service.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../..");

describe("economy rules", () => {
  it("calculates 270 total return for a 100 burmalda winning bet", () => {
    expect(Math.floor(100 * 2.7)).toBe(270);
  });

  it("daily mission claim key is stable per mission and day", () => {
    const now = new Date("2026-04-21T10:00:00.000Z");
    expect(missionRewardKey("user-1", "play_five_rounds", now)).toBe(
      "mission_reward:user-1:play_five_rounds:2026-04-21"
    );
  });

  it("rescue refill respects the 3 hour cooldown", () => {
    const now = new Date("2026-04-21T10:00:00.000Z");
    expect(canClaimRescue(150, new Date("2026-04-21T06:30:00.000Z"), now)).toBe(true);
    expect(canClaimRescue(150, new Date("2026-04-21T08:00:01.000Z"), now)).toBe(false);
    expect(canClaimRescue(250, null, now)).toBe(false);
  });

  it("models one bet per round with a composite key", () => {
    const seen = new Set<string>();
    const key = "user-1:round-1";
    seen.add(key);
    expect(seen.has(key)).toBe(true);
  });

  it("boost purchase deducts burmalda only when funds are enough", () => {
    expect(canPurchaseBoost(100, 50)).toBe(true);
    expect(canPurchaseBoost(40, 50)).toBe(false);
  });

  it("referral codes are parsed deterministically", () => {
    expect(parseReferralCode("ref_777")).toBe("777");
    expect(parseReferralCode("hello")).toBeNull();
  });

  it("activity feed items match the expected structure", () => {
    expect(
      isActivityFeedItem({
        id: "activity-1",
        kind: "system",
        text: "В этом раунде сделано выборов: 12"
      })
    ).toBe(true);
  });

  it("UI copy no longer exposes money or subscription prompts", () => {
    const pageSource = fs.readFileSync(path.join(root, "apps/frontend/src/app/page.tsx"), "utf8").toLowerCase();
    const forbidden = ["real money", "subscriptions", "premium purchase", "buy coins", "top up", "store"];
    for (const term of forbidden) expect(pageSource).not.toContain(term);
  });
});
