import { describe, expect, it } from "vitest";
import { roundConfig } from "../src/config.js";
import { generateRoundFromSeed, verifyRound } from "../src/services/round-engine.js";

describe("round engine", () => {
  it("is deterministic", () => {
    const a = generateRoundFromSeed("seed-a", roundConfig);
    const b = generateRoundFromSeed("seed-a", roundConfig);
    expect(a).toEqual(b);
  });

  it("verifyRound reproduces result", () => {
    expect(verifyRound("seed-b", roundConfig)).toEqual(generateRoundFromSeed("seed-b", roundConfig));
  });
});
