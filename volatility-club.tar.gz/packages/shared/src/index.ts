import { z } from "zod";

export const userStatusSchema = z.enum(["active", "suspicious", "soft_banned", "hard_banned"]);
export type UserStatus = z.infer<typeof userStatusSchema>;

export const roundStatusSchema = z.enum(["upcoming", "active", "finished", "cancelled"]);
export type RoundStatus = z.infer<typeof roundStatusSchema>;

export const betStatusSchema = z.enum(["pending", "won", "lost", "cancelled"]);
export type BetStatus = z.infer<typeof betStatusSchema>;

export const assetIdSchema = z.string().min(1).max(64);

export const profilePatchSchema = z.object({
  nickname: z
    .string()
    .trim()
    .min(2)
    .max(24)
    .regex(/^[a-zA-Z0-9а-яА-ЯёЁ _.-]+$/u, "Nickname contains unsupported characters")
    .optional(),
  rulesAccepted: z.boolean().optional(),
  deviceFingerprint: z.string().trim().max(256).optional()
});

export const authTelegramSchema = z.object({
  initData: z.string().min(20).max(8192),
  deviceFingerprint: z.string().trim().max(256).optional()
});

export const placeBetSchema = z.object({
  roundId: z.string().uuid(),
  assetId: z.string().uuid()
});

export const missionIdSchema = z.enum(["play_five_rounds", "win_two_rounds", "streak_two_wins"]);
export type MissionId = z.infer<typeof missionIdSchema>;

export const claimMissionSchema = z.object({
  missionId: missionIdSchema
});

export const roundBoostTypeSchema = z.enum(["chart", "hint"]);
export type RoundBoostType = z.infer<typeof roundBoostTypeSchema>;

export const historyQuerySchema = z.object({
  limit: z.coerce.number().int().min(1).max(20).default(10)
});

export const leaderboardQuerySchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional()
});

export type AssetChartPoint = {
  tick: number;
  value: number;
};

export type RoundAssetView = {
  id: string;
  name: string;
  volatilityType: string;
  chartData: AssetChartPoint[];
  finalReturn: number;
};

export type PublicUser = {
  id: string;
  telegramUserId: string;
  username: string | null;
  firstName: string | null;
  photoUrl: string | null;
  nickname: string | null;
  balance: number;
  status: UserStatus;
  rulesAcceptedAt: string | null;
  currentStreak?: number;
  bestStreak?: number;
};
